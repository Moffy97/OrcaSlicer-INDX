Mainsail INDX: tema, navigazione e panoramica in sola lettura.
Installazione di riferimento SV08 Max con utente sovol e modalita manutenzione.
Revisionare i percorsi nello script prima di usarlo su altre macchine. Copiare i file nella cartella stage indicata dallo script. Eseguire solo dopo backup. Lo script salva preferenze e tema precedenti.
La pagina legge i dati del servizio INDX; non invia G-code.
