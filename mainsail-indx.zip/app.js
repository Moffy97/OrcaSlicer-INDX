'use strict';
// Read-only: never send G-code or change shared filament/configuration files.
const $=id=>document.getElementById(id);
const text=(tag,value,cls)=>{const e=document.createElement(tag);e.textContent=value;if(cls)e.className=cls;return e;};
async function read(path,optional=false){const r=await fetch(path,{cache:'no-store',signal:AbortSignal.timeout(7000)});if(optional&&r.status===404)return null;if(!r.ok)throw new Error('HTTP '+r.status);return r.json();}
function value(v,unit=''){return typeof v==='number'&&Number.isFinite(v)?new Intl.NumberFormat('it-IT',{maximumFractionDigits:3}).format(v)+unit:'—';}
function card(tool,record){const el=text('article','','tool');const top=text('div','','tool-top');top.append(text('h3','T'+tool.tool),text('span',tool.confirmed?value(tool.diameter,' mm')+' · '+(tool.type==='cht'?'CHT':'Standard'):'Ugello da confermare','nozzle'));el.append(top);
 if(!record){el.append(text('p','Nessun filamento assegnato','empty'));return el;}
 const row=text('div','','filament'),dot=text('span','','swatch');dot.style.backgroundColor=/^#[\da-f]{6}$/i.test(record.color||'')?record.color:'#738795';dot.setAttribute('aria-label','Colore del filamento');row.append(dot,text('b',record.type||'Materiale non definito'));el.append(row,text('div',record.name||record.product||'Profilo senza nome','profile'));
 const vals=text('div','','values');for(const [label,v] of [['Ugello',value(record.temp,' °C')],['Piatto',value(record.bed,' °C')],['Flow',value(record.flow)],['Portata massima',value(record.max_flow,' mm³/s')]]){const cell=text('div','');cell.append(text('span',label),text('b',v));vals.append(cell);}el.append(vals);
 el.append(text('div',record.profile_mode==='standard'?'Profilo standard · valori stock. Calibrazioni da verificare per questo tool e ugello.':'Profilo personalizzato · verificare le calibrazioni per tool e ugello da KlipperScreen.','calibration'));return el;}
let busy=false;
async function refresh(){if(busy)return;busy=true;$('refresh').disabled=true;
 try{const [live,setup,assigned,library]=await Promise.all([read('/printer/objects/query?configfile&print_stats'),read('/server/files/config/indx-tool-setup.json',true),read('/server/files/config/indx-filament-assignments.json',true),read('/server/files/config/indx-filament-library.json',true)]);
 const status=live.result.status,config=status.configfile.config,maintenance=config.printer?.kinematics==='none';const confirmed=Array.isArray(setup?.tools)?setup.tools:[],assignments=assigned||{};
 $('state').textContent=maintenance?'Manutenzione · INDX assente':'Configurazione macchina attiva';$('state').className='badge';
 $('stateDetail').textContent=maintenance?'Interfaccia disponibile. Assi, estrusore e riscaldatori esclusi dal profilo attivo.':'Il software è collegato. La presenza dei tool e il collaudo fisico vanno verificati sulla macchina.';
 $('notice').textContent=maintenance?'In attesa di INDX: puoi provare interfaccia e sincronizzazione. La stampa resta disabilitata; dock, offset e cella di carico richiedono il collaudo fisico.':'Panoramica dei dati salvati. Questi valori non certificano il collaudo fisico né l’idoneità alla stampa.';
 $('count').textContent=confirmed.length;$('assigned').textContent=Object.keys(assignments).length;$('library').textContent=Object.keys(library?.profiles||{}).length;
 const ids=[...new Set([...confirmed.map(t=>t.tool),...Object.keys(assignments).map(Number)])].filter(t=>Number.isInteger(t)&&t>=0&&t<64).sort((a,b)=>a-b);
 const cards=ids.map(id=>{const t=confirmed.find(t=>t.tool===id);return card(t?{...t,confirmed:true}:{tool:id,confirmed:false},assignments[String(id)]);});
 if(!cards.length)cards.push(text('p','Nessun tool confermato. Aggiungilo da KlipperScreen → INDX → Tool e dock.','empty'));$('tools').replaceChildren(...cards);$('updated').textContent='Dati aggiornati alle '+new Date().toLocaleTimeString('it-IT');
 }catch(error){$('state').textContent='Dati non disponibili';$('stateDetail').textContent='Connessione interrotta o accesso richiesto. Verifica il collegamento in Mainsail.';$('notice').textContent='Aggiornamento non riuscito. I dati precedenti sono stati nascosti per evitare di mostrarli come attuali.';for(const id of ['count','assigned','library'])$(id).textContent='—';$('tools').replaceChildren(text('p','Riprova con “Aggiorna dati”.','empty'));$('updated').textContent='Ultimo aggiornamento non riuscito';}
 finally{busy=false;$('refresh').disabled=false;}}
$('refresh').addEventListener('click',refresh);document.addEventListener('visibilitychange',()=>{if(!document.hidden)refresh();});setInterval(()=>{if(!document.hidden)refresh();},15000);refresh();
