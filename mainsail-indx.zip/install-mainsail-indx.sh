set -eu
python3 - <<'PY'
from pathlib import Path
import urllib.request,json,shutil,datetime,hashlib
root=Path('/home/sovol/printer_data/config');web=Path('/home/sovol/mainsail');stage=Path('/home/sovol/indx-preview-0.2.0')
def api(path,data=None):
 req=urllib.request.Request('http://127.0.0.1:7125'+path,data=json.dumps(data).encode() if data is not None else None,headers={'Content-Type':'application/json'})
 return json.load(urllib.request.urlopen(req,timeout=15))['result']
db=api('/server/database/item?namespace=mainsail')['value']
backup=root/('backup-mainsail-indx-'+datetime.datetime.now().strftime('%Y%m%d-%H%M%S'));backup.mkdir()
(backup/'mainsail-database.json').write_text(json.dumps(db,indent=2))
theme=root/'.theme';theme.mkdir(exist_ok=True);target=web/'indx'
if target.exists():shutil.copytree(target,backup/'indx')
for name in ['custom.css','sidebar-logo.svg','navi.json']:
 if (theme/name).exists():shutil.copy2(theme/name,backup/name)
entries=json.loads((theme/'navi.json').read_text()) if (theme/'navi.json').exists() else []
assert isinstance(entries,list)
entries=[x for x in entries if x.get('href')!='/indx/']
entries.append({'title':'INDX — Tool e filamenti','href':'/indx/','target':'_self','position':15,'icon':'M4 3H20V7H18V13L14 17V21H10V17L6 13V7H4V3M8 7V12L12 16L16 12V7H8Z'})
(theme/'navi.json').write_text(json.dumps(entries,ensure_ascii=False,indent=2))
old_css=(theme/'custom.css').read_text() if (theme/'custom.css').exists() else ''
marker='/* INDX theme:'
if marker in old_css:old_css=old_css[:old_css.index(marker)]
(theme/'custom.css').write_text(old_css+'\n'+(stage/'custom.css').read_text())
shutil.copy2(stage/'sidebar-logo.svg',theme/'sidebar-logo.svg')
target.mkdir(exist_ok=True)
for name in ['index.html','style.css','app.js']:shutil.copy2(stage/name,target/name)
values={'general.printername':'SV08 Max INDX','general.language':'it','uiSettings.primary':'#51CCB5','uiSettings.logo':'#51CCB5','uiSettings.mode':'dark','uiSettings.boolWideNavDrawer':True,'uiSettings.tempchartHeight':190}
groups=dict(db.get('macros',{}).get('macrogroups',{}))
definitions=[('indx-status','Stato INDX','primary',['STATO_MANUTENZIONE','INDX_PREVIEW']),('indx-operations','INDX · procedure protette','warning',['INDX_CLEAN_NOZZLE','INDX_PRINT_START','INDX_PRINT_END']),('indx-pause','Pausa al layer','secondary',['SET_PAUSE_AT_LAYER','SET_PAUSE_NEXT_LAYER'])]
for ident,name,color,macros in definitions:
 groups[ident]={'id':ident,'name':name,'color':color,'showInStandby':True,'showInPrinting':True,'showInPause':True,'macros':[{'pos':i,'name':m,'color':'group','showInStandby':True,'showInPrinting':True,'showInPause':True} for i,m in enumerate(macros)]}
values['macros.macrogroups']=groups;values['macros.mode']='expert'
for key,value in values.items():api('/server/database/item',{'namespace':'mainsail','key':key,'value':value})
(backup/'changed-keys.json').write_text(json.dumps(list(values)))
for name in ['index.html','style.css','app.js']:
 downloaded=urllib.request.urlopen('http://127.0.0.1/indx/'+name).read()
 assert hashlib.sha256(downloaded).digest()==hashlib.sha256((stage/name).read_bytes()).digest(),name
assert api('/printer/info')['state']=='ready'
assert api('/printer/objects/query?configfile')['status']['configfile']['config']['printer']['kinematics']=='none'
print('Installed Mainsail INDX theme, navigation, read-only live overview, grouped macros.');print('Backup:',backup)
print('PASS: all served assets match payload; Klipper remains ready in maintenance; no restart, motion or heating.')
PY
