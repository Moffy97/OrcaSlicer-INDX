from pathlib import Path
import re,math,json,statistics,collections
root=Path(__file__).resolve().parent;p=root/'pareti02-infill08-verifica.gcode'
lines=p.read_text(encoding='utf-8').splitlines()
config={}
for line in lines:
 m=re.match(r'; ([a-z_0-9]+) = (.*)',line)
 if m:config[m[1]]=m[2]
tool=None;role=None;h=0.;width=0.;layer_z=None;layers=[];rows=[];x=y=z=0.;e=0.;relative=False
for lineno,line in enumerate(lines,1):
 if line.startswith(';Z:'):
  layer_z=float(line[3:]);layers.append(layer_z)
 elif line.startswith(';HEIGHT:'):h=float(line[8:])
 elif line.startswith(';WIDTH:'):width=float(line[7:])
 elif line.startswith(';TYPE:'):role=line[6:]
 if re.fullmatch(r'T\d+',line):tool=int(line[1:])
 if line.startswith('M83'):relative=True
 if line.startswith('M82'):relative=False
 cmd=line.split(';',1)[0].strip()
 if not cmd:continue
 args={k:float(v) for k,v in re.findall(r'([XYZE])([-+]?(?:\d*\.\d+|\d+\.?\d*))',cmd)}
 if cmd.startswith('G92'):
  if 'E' in args:e=args['E']
  continue
 if re.match(r'G[01](?:\s|$)',cmd):
  nx=args.get('X',x);ny=args.get('Y',y);nz=args.get('Z',z)
  de=args.get('E',0.) if relative else args.get('E',e)-e
  length=math.hypot(nx-x,ny-y)
  if de>0 and length>1 and role in ('Outer wall','Inner wall','Sparse infill'):
   rows.append(dict(line=lineno,tool=tool,role=role,z=nz,layer_z=layer_z,height=h,width=width,length=length,e=de))
  if 'E' in args:e=e+args['E'] if relative else args['E']
  x,y,z=nx,ny,nz
walls=[r for r in rows if r['role'] in ('Outer wall','Inner wall')]
infill=[r for r in rows if r['role']=='Sparse infill']
combined=[r for r in infill if r['height']>.15]
assert walls and infill and combined
assert {r['tool'] for r in walls}=={0}
assert {r['tool'] for r in infill}=={1}
assert max(r['height'] for r in walls)<=.140002
assert max(r['height'] for r in combined)<=.560002
assert all(abs(r['z']-r['layer_z'])<.00051 for r in rows)
heights=[layers[0]]+[b-a for a,b in zip(layers,layers[1:])]
bands=sorted({r['layer_z'] for r in combined})
for band in bands:
 i=min(range(len(layers)),key=lambda i:abs(layers[i]-band))
 assert abs(sum(heights[i-3:i+1])-.56)<.00001
flow=[float(v) for v in config['filament_flow_ratio'].split(',')]
diam=[float(v) for v in config['filament_diameter'].split(',')]
errors=[]
for r in combined:
 area=r['width']*r['height']-(1-math.pi/4)*r['height']**2
 expected=area*flow[r['tool']]/(math.pi*diam[r['tool']]**2/4)
 actual=r['e']/r['length'];errors.append(abs(actual/expected-1))
assert statistics.median(errors)<.001
report=dict(model_mm=[40,40,12],layer_count=len(layers),top_z=layers[-1],wall_tools=[0],infill_tools=[1],
 wall_heights=sorted({r['height'] for r in walls}),infill_heights=sorted({r['height'] for r in infill}),combined_band_count=len(bands),combined_band_z=bands,
 median_extrusion_volume_relative_error=statistics.median(errors),maximum_extrusion_volume_relative_error=max(errors),
 samples=[walls[5],combined[len(combined)//2]],config={k:config.get(k) for k in ['nozzle_diameter','filament_map','filament_map_mode','outer_wall_filament_id','inner_wall_filament_id','sparse_infill_filament_id','infill_combination','layer_height','max_layer_height','filament_flow_ratio']})
(root/'verifica-numerica.json').write_text(json.dumps(report,indent=2)+'\n')
(root/'VERIFICA.md').write_text('''# Prova di slicing INDX 0,20 / 0,80 mm

Blocco 40 x 40 x 12 mm, 20% riempimento rettilineo. Pareti e superfici T0 (0,20 mm), riempimento sparso T1 (0,80 mm). Prova software isolata, nessun invio alla stampante.

- Richiesta 0,40 mm adattata automaticamente a 0,14 mm per layer e primo strato.
- 86 layer, quota finale 12,00 mm. Gli ultimi layer sono ridotti a circa 0,132 mm per chiudere il modello.
- Pareti: solo T0, altezza massima 0,14 mm.
- Riempimento: solo T1. 18 gruppi interni da 0,56 mm = somma di quattro layer parete da 0,14 mm.
- Nelle zone di transizione al solido il riempimento puo usare 0,14 mm: la combinazione rispetta la geometria disponibile.
- Controllati gli effettivi movimenti con estrusione: Z coincide con la quota superiore del layer, escludendo le risalite di viaggio.
- Verificato anche il volume E/mm del riempimento combinato, rispetto a larghezza, altezza, diametro filamento e flow ratio.

Il primo export di controllo aveva perso i ruoli e la combinazione durante l'importazione del progetto CLI: e stato scartato. Il risultato valido e `pareti02-infill08-verifica.gcode`; `verifica-numerica.json` contiene campioni e misure. Il progetto di partenza `pareti02-infill08-verifica.3mf` richiede layer 0,40 per permettere di verificare nuovamente l'adattamento automatico all'apertura nella build personalizzata.
''',encoding='utf-8')
print(json.dumps(report,indent=2))

