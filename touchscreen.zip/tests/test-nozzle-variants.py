import importlib.util,pathlib,tempfile,json,math,zlib
root=pathlib.Path('touchscreen')
def load(name):
 s=importlib.util.spec_from_file_location(name,root/(name+'.py'));m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
m=load('indx_profiles');g=load('indx_flow_tests')
with tempfile.TemporaryDirectory() as td:
 m.CONFIG=pathlib.Path(td)
 tools=[dict(tool=t,diameter=d,type='standard',cht_multiplier=1.3) for t,d in enumerate([.4,.4,.6,.8])]
 def hardware(d,kind):
  tools[0].update(diameter=d,type=kind);m.write_json('indx-tool-setup.json',{'schema':1,'tools':tools})
 r=m.assign_profile(dict(name='Mio PLA blu',profile_id='Generic PLA',generic_base=True,base='orca:Generic PLA',color='#1234AB',temp=215,bed=60,flow=1,max_flow=12),0)
 uid=r['library_id'];m.save_calibration(0,'pa',.043);m.save_calibration(0,'flow',.97);m.save_calibration(0,'max_flow',18)
 m.save_calibration(0,'pa',.043) # retest PA after changing flow
 hardware(.4,'cht');r=m.assigned(0)
 assert m.resolve_pa(r,0,{}) is None and r['flow']==1 and math.isclose(r['max_flow'],15.6)
 m.save_calibration(0,'pa',.061);m.save_calibration(0,'flow',.99);m.save_calibration(0,'max_flow',21)
 m.save_calibration(0,'pa',.061)
 hardware(.6,'cht');r=m.assigned(0);assert m.resolve_pa(r,0,{}) is None and r['flow']==1
 m.save_calibration(0,'pa',.077)
 hardware(.4,'standard');r=m.assigned(0)
 assert m.resolve_pa(r,0,{})==.043 and r['flow']==.97 and r['max_flow']==18
 hardware(.4,'cht');r=m.assigned(0)
 assert m.resolve_pa(r,0,{})==.061 and r['flow']==.99 and r['max_flow']==21
 assert len(m.library())==1 and len(m.library()[uid]['calibration_variants'])==3
 hardware(.25,'standard');r=m.assigned(0);assert m.resolve_pa(r,0,{}) is None
 bad={'schema':2,'profiles':[],'tools':tools};bad['tools'][0]['diameter']=0
 try:m.decode_catalog(zlib.compress(json.dumps(bad).encode()));raise AssertionError('invalid hardware accepted')
 except ValueError:pass
for d in [.1,.15,.25,.35,.5,.7,1.,1.2,2.]:
 code,_=g.flow_test(0,215,60,1,nozzle=d);assert 'nan' not in code and 'inf' not in code
 h=g.max_flow_layer_height(d);ceiling=g.area(d*1.1,h)*300
 start=.2;end=min(10,math.floor(ceiling*10)/10)
 code,qs=g.max_flow_test(0,215,60,1,start=start,end=end,step=max(.1,(end-start)/10),nozzle=d)
 assert len(qs)>1 and all(math.isfinite(q) for q in qs)
print('PASS: independent arbitrary diameters; Standard/CHT archive and recall; calibrated max flow wins over estimates; no cross-hardware PA/flow; 9 diameters generate bounded valid tests; invalid catalog tools rejected.')
