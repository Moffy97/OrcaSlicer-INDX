from pathlib import Path
import sys,tempfile,json,copy,importlib.util,re,ast,types
root=Path('touchscreen') if Path('touchscreen').exists() else Path('outputs/INDX-PA');spec=importlib.util.spec_from_file_location('machine',root/'indx_machine.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
fixture=Path('work/indx-macros/indx.cfg').read_text(encoding='utf-8') if Path('work/indx-macros/indx.cfg').exists() else '[gcode_macro TOOL_POSITIONS]\nvariable_tool_count: 4\nvariable_dock_dir: -1\nvariable_clearance_y: 60\nvariable_trigger_offset: 5\nvariable_z_hop: 1\nvariable_docks_calibrated: False\nvariable_tools: []\ngcode:\n'
def candidate(n):return {'schema':1,'dock_dir':-1,'clearance_y':80.,'trigger_offset':5.,'z_hop':3.,'tools':[dict(tool=t,diameter=.4,type='cht' if t%2 else 'standard',cht_multiplier=1.3,x=20.+t*35,dock_y=30.,offset_x=0.,offset_y=0.,offset_z=0.) for t in range(n)]}
def state():return {'print_stats':{'state':'standby'},'idle_timeout':{'state':'Idle'},'configfile':{'config':{f'stepper_{a}':{'position_min':-50,'position_max':2500} for a in 'xyz'}},'gcode_macro TOOL_POSITIONS':{'docks_calibrated':True},'gcode_macro _INDX_SETUP':{'geometry_verified':True,'cleaning_verified':True}}
with tempfile.TemporaryDirectory() as td:
 r=Path(td);(r/'indx').mkdir();(r/'indx/indx.cfg').write_text(fixture,encoding='utf-8');(r/'printer.cfg').write_text('[printer]\nkinematics: corexy\n');(r/'indx-orca-commissioning.cfg').write_text('[gcode_macro _INDX_SETUP]\nvariable_geometry_verified: True\nvariable_cleaning_verified: True\ngcode:\n  RESPOND MSG="test"\n')
 # A low-resolution clock must not collide when multiple saves run in one tick.
 previous_clock=m.time.time_ns;m.time.time_ns=lambda:123456789
 for n in (1,2,4,6,8,12,64):
  data=candidate(n);s=state();token=m.fingerprint(r);commands=[];revision,backup=m.apply(r,data,token,s,commands.append)
  text=(r/'indx/indx.cfg').read_text(encoding='utf-8');tp=m.literals(m.sections(text)['gcode_macro TOOL_POSITIONS'])
  assert tp['tool_count']==n and tp['docks_calibrated'] is False
  assert Path(backup,'indx/indx.cfg').exists()
  assert m.sections(text).get('gcode_macro T'+str(n-1))
  assert 'MOVE=' not in text.split('# BEGIN INDX SCREEN OFFSETS')[1]
  assert all(c.startswith('SET_GCODE_VARIABLE ') for c in commands[0].splitlines())
  assert all('VALUE=False' in c for c in commands[0].splitlines())
  assert len(json.loads((r/'indx-tool-setup.json').read_text())['tools'])==n
  loaded,_=m.load(r,s);assert loaded['tools'][-1]['offset_z']==0
  assert 'non caricato' in m.applied_status(r,s)
  s['save_variables']={'variables':{'indx_machine_revision':revision,'t0_offset_z':.125}}
  s['gcode_macro TOOL_POSITIONS']['tool_count']=n
  loaded,_=m.load(r,s);assert loaded['tools'][0]['offset_z']==.125
  assert 'Configurazione caricata' in m.applied_status(r,s)
  block=text.split('# BEGIN INDX SCREEN OFFSETS')[1]
  assert block.count('SAVE_VARIABLE VARIABLE=')==3*n+1
  assert f"!= '{revision}'" in block
 m.time.time_ns=previous_clock
 assert len(list(r.glob('indx-machine-backup-*')))==7
 # An explicit operator confirmation requires the loaded revision, real head
 # configuration and matching runtime geometry. Full commissioning needs the checklist.
 s=state();s['save_variables']={'variables':{'indx_machine_revision':revision}}
 s['gcode_macro TOOL_POSITIONS'].update({k:data[k] for k in ('dock_dir','clearance_y','trigger_offset','z_hop')});s['gcode_macro TOOL_POSITIONS']['tool_count']=64
 for row in data['tools']:
  for k in ('x','dock_y'):s['gcode_macro TOOL_POSITIONS'][f"t{row['tool']}_{k}"]=row[k]
 try:m.confirm_commissioning(r,s,m.fingerprint(r),lambda _:None)
 except ValueError:pass
 else:raise AssertionError('Maintenance commissioning accepted')
 s['configfile']['config'].update({'mcu indxmcu':{},'load_cell_probe':{}})
 sent=[];m.confirm_commissioning(r,s,m.fingerprint(r),sent.append)
 assert sent==['SET_GCODE_VARIABLE MACRO=TOOL_POSITIONS VARIABLE=docks_calibrated VALUE=True']
 spec=importlib.util.spec_from_file_location('guide',root/'indx_commissioning.py');guide=importlib.util.module_from_spec(spec);spec.loader.exec_module(guide)
 panels=types.ModuleType('panels');panels.indx_commissioning=guide;sys.modules['panels']=panels
 try:m.confirm_commissioning(r,s,m.fingerprint(r),lambda _:None,True)
 except ValueError:pass
 else:raise AssertionError('Incomplete checklist accepted')
 hw=json.loads((r/'indx-tool-setup.json').read_text());check={}
 for key,_,_ in guide.STEPS[:-1]:check=guide.save_step(check,hw,key,True,'test fixture')
 (r/'indx-commissioning.json').write_text(json.dumps(check));sent=[];m.confirm_commissioning(r,s,m.fingerprint(r),sent.append,True)
 assert 'VARIABLE=geometry_verified VALUE=True' in sent[0]
 assert 'variable_cleaning_verified: True' in (r/'indx-orca-commissioning.cfg').read_text()
 (r/'indx_vars.cfg').write_text('[variables]\nt0_offset_x = 1.25\n')
 assert m.saved_variables(r,{})['t0_offset_x']==1.25
 before={p:p.read_bytes() for p in [r/'indx/indx.cfg',r/'indx-machine-applied.json',r/'indx-tool-setup.json']}
 original_replace=m.os.replace;calls=[0]
 def interrupted(a,b):
  calls[0]+=1
  if calls[0]==2:raise OSError('simulated interrupted file transaction')
  return original_replace(a,b)
 m.os.replace=interrupted
 try:
  try:m.apply(r,candidate(4),m.fingerprint(r),state(),lambda _:None)
  except OSError:pass
  else:raise AssertionError('Interrupted transaction not raised')
 finally:m.os.replace=original_replace
 assert all(p.read_bytes()==content for p,content in before.items())
 data=candidate(4);original=(r/'indx/indx.cfg').read_bytes();bad=copy.deepcopy(data);bad['tools'][0]['x']='0\nG28'
 for wrong in (bad,dict(data,clearance_y=40),dict(data,tools=[])):
  try:m.apply(r,wrong,m.fingerprint(r),state(),lambda _:None)
  except ValueError:pass
  else:raise AssertionError('Invalid geometry accepted')
  assert (r/'indx/indx.cfg').read_bytes()==original
 for busy in ('printing','paused','unknown'):
  s=state();s['print_stats']['state']=busy
  try:m.apply(r,data,m.fingerprint(r),s,lambda _:None)
  except ValueError:pass
  else:raise AssertionError('Busy state accepted')
 for tweak in ('heater','idle','token'):
  s=state();token=m.fingerprint(r)
  if tweak=='heater':s['extruder']={'target':200}
  if tweak=='idle':s['idle_timeout']['state']='Printing'
  if tweak=='token':token='stale'
  try:m.apply(r,data,token,s,lambda _:None)
  except ValueError:pass
  else:raise AssertionError(tweak)
 # A gate command failure must leave the configuration untouched.
 def reject(_):raise RuntimeError('simulated network failure')
 try:m.apply(r,data,m.fingerprint(r),state(),reject)
 except RuntimeError:pass
 else:raise AssertionError('Failed gate accepted')
 assert (r/'indx/indx.cfg').read_bytes()==original
 (r/'indx-machine-paths.json').write_text(json.dumps({'config':'../escape.cfg'}))
 try:m.paths(r)
 except ValueError:pass
 else:raise AssertionError('Escaping path accepted')
print('PASS: dock editor 1/2/4/6/8/12/64, complete geometry, bounds/clearance, injection rejection, busy/heater/stale/network guards, backups, dynamic Tn, pending/loaded offsets and official calibration preservation. No printer contacted.')
