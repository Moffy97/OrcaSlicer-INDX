"""Isolated sync, conflict, crash recovery and cache invalidation tests."""
from pathlib import Path
import sys,importlib.util,tempfile,copy,json,zlib,time
root=Path('touchscreen');sys.path.insert(0,str(root.resolve()))
import indx_profiles as store,indx_sync as sync
with tempfile.TemporaryDirectory() as td:
 store.CONFIG=Path(td)
 profile=dict(id='Generic PLA',name='Generic PLA',brand='Generic',material='PLA',generic=True,compatible=True,config={'nozzle_temperature':['215'],'hot_plate_temp':['55'],'filament_flow_ratio':['.98'],'filament_max_volumetric_speed':['9'],'enable_pressure_advance':['1'],'pressure_advance':['.025']})
 raw=zlib.compress(json.dumps(dict(schema=2,profiles=[profile])).encode())
 (store.CONFIG/'indx-orca-catalog-cache.json.z').write_bytes(raw)
 record=store.assign_profile(store.stock_record(profile,0,'#2277AA'),0)
 record=store.save_calibration(0,'flow',1.01);uid=record['library_id']
 def change(tool,desired):
  a=store.read_json('indx-filament-assignments.json',{}).get(str(tool))
  return dict(tool=tool,desired=desired,expected_assignment=a,expected_record=store.library().get((a or {}).get('library_id')),expected_setup=store.read_json('indx-tool-setup.json',{}))
 def request(token,*changes):return dict(schema=1,request_id=token,changes=list(changes))
 cmd=request('color-change-0001',change(0,dict(library_id=uid,color='#D24499')))
 ack=sync.apply_request(cmd);assert ack['status']=='applied'
 assert store.assigned(0)['color']=='#D24499' and store.calibration(store.assigned(0),0)['flow']==1.01
 # Idempotent replay cannot create another history entry or bump revision.
 before=copy.deepcopy(store.library());assert sync.apply_request(cmd)==ack;assert store.library()==before
 # An offline/stale Orca request cannot overwrite a later touch edit.
 stale=request('conflict-test-0002',change(0,dict(library_id=uid,color='#FFFFFF')))
 r=store.library()[uid];r['color']='#112233';store.save_profile(r)
 before=copy.deepcopy(store.library());assert sync.apply_request(stale)['status']=='conflict';assert store.library()==before
 # Batch rejects all changes when one tool conflicts; no partial writes.
 stale=request('batch-test-000003',change(1,dict(profile_id='Generic PLA',color='#FF0000')),change(0,dict(library_id=uid,color='#000000')))
 r=store.library()[uid];r['name']='Touch edit';store.save_profile(r)
 before=copy.deepcopy(store.read_json('indx-filament-assignments.json',{}));assert sync.apply_request(stale)['status']=='conflict';assert store.read_json('indx-filament-assignments.json',{})==before
 cmd=request('base-test-0000004',change(1,dict(profile_id='Generic PLA',color='#55AA22')))
 assert sync.apply_request(cmd)['status']=='applied';stock=store.assigned(1)
 assert stock['profile_mode']=='standard' and stock['temp']==215 and stock['flow']==.98 and not store.calibration(stock,1)
 assert store.effective_values(stock,1)==dict(pa=.025,flow=.98,max_flow=9)
 # Switching a calibrated profile recalls applicable calibration and temperature.
 cmd=request('recall-test-00005',change(0,dict(library_id=uid,color='#112233')))
 assert sync.apply_request(cmd)['status']=='applied' and store.calibration(store.assigned(0),0)['flow']==1.01
 # Independent color on a shared profile must not recolor other tools.
 store.assign_profile(store.library()[uid],2)
 cmd=request('split-color-00006',change(0,dict(library_id=uid,color='#AA77FF')))
 assert sync.apply_request(cmd)['status']=='applied';assert store.assigned(2)['color']=='#112233' and store.assigned(0)['color']=='#AA77FF'
 # Consumer waits while printing, then handles the same request once idle.
 cmd=request('busy-test-0000007',change(3,dict(profile_id='Generic PLA',color='#55AA22')));store.write_json(sync.REQUEST,cmd)
 assert sync.poll(lambda:True) is None and store.assigned(3) is None
 assert sync.poll(lambda:False)['status']=='applied' and sync.poll(lambda:False) is None
 # Invalid profile/color cannot write library data.
 before=copy.deepcopy(store.library())
 for token,desired in [('bad-color-0000008',dict(profile_id='Generic PLA',color='red')),('bad-base-00000009',dict(profile_id='missing',color='#FFFFFF'))]:
  assert sync.apply_request(request(token,change(0,desired)))['status']=='error';assert store.library()==before
 # Recovery completes a committed journal before a new local save can run.
 journal={'indx-filament-library.json':{'schema':3,'profiles':store.library()},'indx-filament-assignments.json':store.read_json('indx-filament-assignments.json',{}),sync.ACK:dict(request_id='recovered-0000010',status='applied')}
 store.write_json('indx-orca-sync-journal.json',journal)
 with store.transaction():assert not (store.CONFIG/'indx-orca-sync-journal.json').exists()
 assert store.read_json(sync.ACK,{})['request_id']=='recovered-0000010'
 # JSON reads are defensive; external atomic replacement invalidates both caches.
 snapshot=store.library();snapshot.clear();assert store.library()
 original=store.catalog();assert store.catalog() is original
 profile['name']='Updated catalog';temporary=store.CONFIG/'replacement.tmp';temporary.write_bytes(zlib.compress(json.dumps(dict(schema=2,profiles=[profile])).encode()));temporary.replace(store.CONFIG/'indx-orca-catalog-cache.json.z')
 assert store.catalog() is not original and store.catalog()['profiles'][0]['name']=='Updated catalog'
 store.write_json('cache-test.json',{'value':1});assert store.read_json('cache-test.json',{})['value']==1
 (store.CONFIG/'external.tmp').write_text('{"value":2}');(store.CONFIG/'external.tmp').replace(store.CONFIG/'cache-test.json');assert store.read_json('cache-test.json',{})['value']==2
print('PASS reverse sync: stock/custom recall, colors, valid calibration retained, idempotence, concurrent-edit rejection, all-or-nothing validation, printing deferral, recovery, independent shared-tool colors, external cache invalidation.')
