import pathlib,json,zlib,tempfile,threading,time,importlib.util,py_compile
root=pathlib.Path('touchscreen')
for p in root.glob('indx_*.py'):py_compile.compile(str(p),doraise=True)
spec=importlib.util.spec_from_file_location('profiles',root/'indx_profiles.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
profiles=[dict(id='PLA standard',name='PLA standard',config={'nozzle_temperature':['210']},source='system',revision='r1',compatible=True),dict(id='Mio PLA',name='Mio PLA',config={'pressure_advance':['.041']},source='user',revision='r2',compatible=True)]
fixture={'schema':2,'profiles':profiles,'request_id':''}
assert len(m.decode_catalog(zlib.compress(json.dumps(fixture).encode()))['profiles'])==2
try:m.decode_catalog(zlib.compress(json.dumps(dict(fixture,profiles=[profiles[0],profiles[0]])).encode()));raise AssertionError('duplicate not rejected')
except ValueError:pass
with tempfile.TemporaryDirectory() as td:
 m.CONFIG=pathlib.Path(td)
 def orca():
  deadline=time.monotonic()+3
  while time.monotonic()<deadline:
   request=m.read_json('indx-orca-catalog-request.json',{})
   if request:
    data=dict(fixture,request_id=request['request_id']);(m.CONFIG/'indx-orca-catalog.json.z').write_bytes(zlib.compress(json.dumps(data).encode()));return
   time.sleep(.05)
 thread=threading.Thread(target=orca);thread.start();data=m.refresh_catalog(timeout=3);thread.join()
 assert data['request_id'] and m.catalog()==data
 record={'name':'Mia bobina','base':'orca:Mio PLA','profile_revision':'r2'}
 results={'Mia bobina|T0':dict(base='orca:Mio PLA',nozzle=.4,pa=.041,profile_revision='r2')}
 assert m.resolve_pa(record,0,results)==.041
 assert m.resolve_pa(record,1,results) is None
 assert m.resolve_pa(record,2,results) is None
 assert m.resolve_pa(dict(record,profile_revision='r3'),0,results) is None
 try:m.refresh_catalog(timeout=.1);raise AssertionError('stale catalog accepted')
 except RuntimeError:pass
print('PASS: catalogo standard/personale, richiesta nuova e risposta corrispondente, cache integra, profili duplicati respinti, PA distinto per utensile/revisione, nessuna risposta vecchia accettata.')
