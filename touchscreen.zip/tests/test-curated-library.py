import importlib.util,tempfile,pathlib,math,re,json,copy,py_compile
root=pathlib.Path('touchscreen')
def load(name):
 spec=importlib.util.spec_from_file_location(name,root/(name+'.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
for p in root.glob('indx_*.py'):py_compile.compile(str(p),doraise=True)
m=load('indx_profiles');g=load('indx_flow_tests')
with tempfile.TemporaryDirectory() as td:
 m.CONFIG=pathlib.Path(td)
 base=dict(name='Marca PLA blu',brand='Marca',product='PLA blu',profile_id='PLA base',base='orca:PLA base',profile_revision='r1',color='#1234AB',temp=215,bed=60,flow=1.,max_flow=12.)
 first=m.assign_profile(base,0);key=first['library_id']
 m.save_calibration(0,'pa',.043,name='Il mio PLA blu')
 m.save_calibration(0,'flow',.97);m.save_calibration(0,'max_flow',18.)
 assert len(m.library())==1 and m.assigned(0)['name']=='Il mio PLA blu'
 assert m.assigned(0)['flow']==.97 and m.assigned(0)['max_flow']==18
 assert m.resolve_pa(m.assigned(0),0,{})==.043
 assert m.resolve_pa(m.assigned(0),2,{}) is None
 m.assign_profile(m.library()[key],2)
 assert m.assigned(2)['flow']==1 and m.assigned(2)['max_flow']==12
 m.save_calibration(2,'pa',.052);m.save_calibration(2,'flow',1.025)
 assert m.assigned(0)['flow']==.97 and m.assigned(2)['flow']==1.025
 other=m.assign_profile(dict(base,name='Un altro PETG',type='PETG'),0)
 assert other['library_id']!=key and len(m.library())==2
 restored=m.assign_profile(m.library()[key],0)
 assert restored['color']=='#1234AB' and restored['temp']==215 and restored['flow']==.97
 assert m.resolve_pa(restored,0,{})==.043
 # A source revision change must not erase an independently saved printer calibration.
 r=dict(m.library()[key],profile_revision='r2');m.save_profile(r)
 assert m.resolve_pa(m.assigned(0),0,{})==.043
 before=copy.deepcopy(m.library())
 for field,value in [('flow',float('nan')),('max_flow',0),('color','red'),('temp',500)]:
  try:m.save_profile(dict(base,**{field:value}));raise AssertionError('Invalid '+field+' accepted')
  except ValueError:pass
 assert m.library()==before

for t in range(4):
 for fine in (.01,.02):
  code,values=g.flow_test(t,215,60,.97,step=fine,old_pa=.043)
  assert len(values)==7 and values[3]==.97 and code.splitlines()[1]=='_INDX_REQUIRE_COMMISSIONED'
  assert code.count('; CAMPIONE')==35
  for line in code.splitlines():
   if line.startswith('G1 X'):
    xy=dict((k,float(v)) for k,v in re.findall(r'([XY])(-?[\d.]+)',line))
    assert 130<=xy['X']<=223 and 145<=xy['Y']<=191
  assert 'M221 S100' in code and 'INDX_PRINT_END' in code
  # Feed/extrusion math must agree with the advertised volume flow.
 code,qs=g.max_flow_test(t,215,60,.97,start=5,end=20,step=1,old_pa=.043)
 h=min(.4,g.NOZZLES[t]/2);cross=g.area(g.NOZZLES[t]*1.1,h)*.97
 band=-1
 for line in code.splitlines():
  if line.startswith('; FASCIA'):band=float(re.search(r'Q=([\d.]+)',line).group(1))
  elif line.startswith('G1 X230 Y145 E'):
   e,feed=map(float,re.search(r'E([\d.]+) F([\d.]+)',line).groups())
   assert math.isclose(e*g.FILAMENT_AREA/100*feed/60,band,rel_tol=.0001)
 assert 'G91\nG1 Z5 F600\nG90' in code # lift from current height, never descend into tower
 assert qs==list(range(5,21))
try:g.max_flow_test(0,215,60,1,end=60);raise AssertionError('unsafe speed accepted')
except ValueError:pass
print('PASS: rename without duplicates; filament swap and recall; color/temps retained; PA/flow/max-flow separated by tool; invalid data rejected; 4 tool specimen geometry and volumetric math; commissioning gate first; tower lift relative; excessive speed rejected.')
