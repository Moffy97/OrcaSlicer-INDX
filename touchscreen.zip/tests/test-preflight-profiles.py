"""Calibration provenance, dynamic tool counts and catalog/hardware separation."""
import importlib.util,pathlib,tempfile,json,zlib,threading,time
root=pathlib.Path('touchscreen')
spec=importlib.util.spec_from_file_location('store',root/'indx_profiles.py');store=importlib.util.module_from_spec(spec);spec.loader.exec_module(store)
with tempfile.TemporaryDirectory() as td:
 store.CONFIG=pathlib.Path(td)
 base=dict(name='Example PLA blue',brand='Example',product='Blue',type='PLA',color='#1234AB',temp=215,bed=60,flow=1.,max_flow=12.,profile_id='Generic PLA',generic_base=True)
 for count in (1,2,4,8,12,64):
  tools=[dict(tool=t,diameter=.4,type='standard',cht_multiplier=1.3) for t in range(count)]
  store.confirm_hardware(tools)
  assert store.tool_count()==len(store.NOZZLES)==count
  assert len(list(store.NOZZLES))==count
  r=store.assign_profile(base,count-1);uid=r['library_id']
  assert store.calibration_states(r,count-1)['flow']['state']=='estimated'
  store.save_calibration(count-1,'flow',.97)
  store.save_calibration(count-1,'pa',.04)
  store.save_calibration(count-1,'max_flow',18)
  master=store.library()[uid]
  assert all(v['state']=='verified' for v in store.calibration_states(master,count-1).values())
  renamed=dict(master,name='Renamed '+str(count),color='#000000');store.save_profile(renamed)
  assert store.resolve_pa(store.assigned(count-1),count-1,{})==.04
  hot=dict(renamed,temp=220);store.save_profile(hot)
  assert all(v['state']=='stale' for v in store.calibration_states(hot,count-1).values())
  assert store.resolve_pa(store.assigned(count-1),count-1,{}) is None
  assert store.assigned(count-1)['flow']==1.
  store.save_profile(renamed)
  assert store.resolve_pa(store.assigned(count-1),count-1,{})==.04
  store.save_calibration(count-1,'flow',1.02)
  assert store.calibration_states(store.assigned(count-1),count-1)['pa']['state']=='stale'
  assert store.calibration_states(store.assigned(count-1),count-1)['max_flow']['state']=='stale'
  store.save_calibration(count-1,'pa',.05)
  assert store.resolve_pa(store.assigned(count-1),count-1,{})==.05
  # Removing and restoring a tool preserves its library identity and variants.
  store.confirm_hardware(tools[:1]);store.confirm_hardware(tools)
  assert store.resolve_pa(store.assigned(count-1),count-1,{})==.05
  assert uid in store.library()
 # An Orca reply describes a different project, not the physical mounting.
 physical=store.read_json('indx-tool-setup.json',{})
 def reply():
  while not (store.CONFIG/'indx-orca-catalog-request.json').exists():time.sleep(.01)
  token=store.read_json('indx-orca-catalog-request.json',{})['request_id']
  data={'schema':2,'request_id':token,'profiles':[],'tools':[dict(tool=0,diameter=.2,type='cht',cht_multiplier=1.3)]}
  (store.CONFIG/'indx-orca-catalog.json.z').write_bytes(zlib.compress(json.dumps(data).encode()))
 worker=threading.Thread(target=reply);worker.start();store.refresh_catalog(timeout=3);worker.join()
 assert store.read_json('indx-tool-setup.json',{})==physical
 assert list((store.CONFIG/'indx-profile-backups').glob('*.json'))
 for tools in ([],[{}]*65):
  try:store.confirm_hardware(tools)
  except ValueError:pass
  else:raise AssertionError('Invalid tool count accepted')
print('PASS: 1/2/4/8/12/64 tool declarations, calibration provenance, temperature/flow invalidation, rename/color preservation, tool removal/restore, catalog cannot overwrite physical declaration, automatic history.')
