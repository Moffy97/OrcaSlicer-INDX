from pathlib import Path
import importlib.util,tempfile,copy
spec=importlib.util.spec_from_file_location('store',Path('touchscreen/indx_profiles.py'));m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
with tempfile.TemporaryDirectory() as td:
 m.CONFIG=Path(td)
 p=dict(id='Generic PLA',name='Generic PLA',brand='Generic',material='PLA',generic=True,revision='stock-v1',config={'nozzle_temperature':['215'],'hot_plate_temp':['55'],'filament_flow_ratio':['.98'],'filament_max_volumetric_speed':['9']})
 stock=m.assign_profile(m.stock_record(p,0,'#2277AA'),0);uid=stock['library_id']
 assert stock['profile_mode']=='standard' and stock['temp']==215 and stock['bed']==55
 assert stock['flow']==.98 and stock['max_flow']==9 and not m.calibration(stock,0)
 again=m.assign_profile(m.stock_record(p,0,'#2277AA'),0);assert again['library_id']==uid
 personal=m.save_calibration(0,'flow',1.01)
 assert personal['library_id']!=uid and personal['profile_mode']=='custom'
 assert not m.library()[uid].get('calibration_variants')
 assert m.calibration(personal,0)['flow']==1.01
 changed=copy.deepcopy(m.library()[personal['library_id']]);changed['color']='#AA2233';m.save_profile(changed)
 assert m.assigned(0)['color']=='#AA2233' and m.calibration(m.assigned(0),0)['flow']==1.01
 print('PASS standard defaults, no false calibration, stable stock reuse, separate custom identity, color recall without calibration invalidation.')
