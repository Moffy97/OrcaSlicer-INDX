import importlib.util,pathlib,copy
root=pathlib.Path('touchscreen')
spec=importlib.util.spec_from_file_location('guide',root/'indx_commissioning.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
h={'tools':[dict(tool=0,diameter=.4,type='standard')]};saved={}
try:g.save_step(saved,h,'xy',True,'not allowed')
except ValueError:pass
else:raise AssertionError('Out-of-order commissioning accepted')
for key,_,_ in g.STEPS:saved=g.save_step(saved,h,key,True,'measured')
assert all(s['done'] for s in saved['steps'].values())
saved=g.save_step(saved,h,'cleaning',False,'needs work')
assert all(not saved['steps'][k]['done'] for k in ('cleaning','z','xy','print'))
assert saved['steps']['docks']['done']
other=copy.deepcopy(h);other['tools'][0]['diameter']=.8
assert g.checklist(saved,other)['steps']=={}
assert g.checklist(saved,dict(h,confirmed_at=999))['steps']
print('PASS: ordered manual commissioning, dependent-step invalidation, hardware-change invalidation, declaration date does not erase results; no movement/firmware calls.')
