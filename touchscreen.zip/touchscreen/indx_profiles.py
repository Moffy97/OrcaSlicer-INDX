"""Shared data helpers for the INDX/Orca profile protocol (schema 2)."""
import json, os, time, uuid, zlib
from pathlib import Path
CONFIG=Path('/home/sovol/printer_data/config')
DEFAULT_NOZZLES=[.4,.4,.6,.8]

def hardware(tool):
    saved=read_json('indx-tool-setup.json',{}).get('tools',[])
    r=saved[tool] if len(saved)==4 else dict(tool=tool,diameter=DEFAULT_NOZZLES[tool],type='standard',cht_multiplier=1.3)
    d=r.get('diameter');kind=r.get('type');factor=r.get('cht_multiplier',1.3)
    if not isinstance(d,(int,float)) or not .1<=d<=2 or kind not in ('standard','cht') or not 1<=factor<=3:raise ValueError('Configurazione ugello non valida')
    return r

class Diameters:
    def __len__(self):return 4
    def __getitem__(self,t):
        if t not in range(4):raise IndexError(t)
        return hardware(t)['diameter']
    def __iter__(self):return (hardware(t)['diameter'] for t in range(4))
NOZZLES=Diameters()

def nozzle_key(tool):
    h=hardware(tool);return f"{tool}:{h['diameter']:.3f}:{h['type']}"

def calibration(record,tool):
    h=hardware(tool);r=record.get('calibration_variants',{}).get(nozzle_key(tool))
    if r is None:r=record.get('calibrations',{}).get(str(tool),{})
    return r if r.get('nozzle')==h['diameter'] and r.get('nozzle_type','standard')==h['type'] else {}

def read_json(name,default):
    p=CONFIG/name
    return json.loads(p.read_text(encoding='utf-8')) if p.exists() else default

def write_json(name,data):
    p=CONFIG/name;tmp=p.with_suffix('.tmp')
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');os.replace(tmp,p)

def decode_catalog(raw):
    if len(raw)>16*1024*1024:raise ValueError('Catalogo compresso troppo grande')
    decoder=zlib.decompressobj();data=decoder.decompress(raw,128*1024*1024)
    if decoder.unconsumed_tail or not decoder.eof:raise ValueError('Catalogo incompleto o troppo grande')
    c=json.loads(data)
    if c.get('schema')!=2 or not isinstance(c.get('profiles'),list):raise ValueError('Formato catalogo non supportato: aprire Orca INDX aggiornato')
    if len(c['profiles'])>30000:raise ValueError('Catalogo fuori limite')
    if c.get('tools'):
        if len(c['tools'])!=4:raise ValueError('Servono quattro tool')
        for t,h in enumerate(c['tools']):
            if h.get('tool')!=t or not isinstance(h.get('diameter'),(int,float)) or not .1<=h['diameter']<=2 or h.get('type') not in ('standard','cht') or not 1<=h.get('cht_multiplier',1.3)<=3:raise ValueError('Configurazione tool non valida')
    seen=set()
    for p in c['profiles']:
        if not isinstance(p,dict) or not isinstance(p.get('config'),dict):raise ValueError('Profilo non valido')
        if not isinstance(p.get('id'),str) or not p['id'] or p['id'] in seen:raise ValueError('Identita profilo non valida o duplicata')
        seen.add(p['id'])
    return c

def catalog():
    p=CONFIG/'indx-orca-catalog-cache.json.z'
    return decode_catalog(p.read_bytes()) if p.exists() else {'schema':2,'profiles':[]}

def refresh_catalog(timeout=40):
    token=uuid.uuid4().hex
    write_json('indx-orca-catalog-request.json',{'request_id':token})
    deadline=time.monotonic()+timeout;last_error=None
    while time.monotonic()<deadline:
        try:
            source=CONFIG/'indx-orca-catalog.json.z';raw=source.read_bytes();c=decode_catalog(raw)
            if c.get('request_id')==token:
                target=CONFIG/'indx-orca-catalog-cache.json.z';tmp=target.with_suffix('.tmp');tmp.write_bytes(raw);os.replace(tmp,target)
                if c.get('tools'):
                    if len(c['tools'])!=4:raise ValueError('Servono quattro tool')
                    write_json('indx-tool-setup.json',{'schema':1,'tools':c['tools']})
                    for t in range(4):hardware(t)
                return c
        except (OSError,ValueError,zlib.error) as e:last_error=e
        time.sleep(.5)
    raise RuntimeError('Orca INDX non ha risposto. Aprilo sul PC con il profilo SV08 Max INDX e controlla il collegamento alla stampante.'+((' '+str(last_error)) if last_error and not isinstance(last_error,FileNotFoundError) else ''))

def first(config,key,default=None):
    value=config.get(key,default)
    return value[0] if isinstance(value,list) and value else value

def number(config,key,default):
    try:return float(first(config,key,default))
    except (ValueError,TypeError):return default

def resolve_pa(record,tool,results):
    if record.get('library_id'):
        saved=calibration(library().get(record['library_id'],{}),tool)
        if saved.get('nozzle')==NOZZLES[tool] and isinstance(saved.get('pa'),(int,float)):
            return saved['pa']
    r=results.get(record['name']+'|T'+str(tool),{})
    if r.get('base')==record.get('base') and r.get('nozzle')==NOZZLES[tool] and hardware(tool)['type']==r.get('nozzle_type','standard') and isinstance(r.get('pa'),(float,int)) and 0<=r['pa']<=1:
        if record.get('profile_revision') and r.get('profile_revision')!=record['profile_revision']:return None
        return r['pa']
    return None

def library():
    return read_json('indx-filament-library.json',{}).get('profiles',{})

def save_profile(record):
    """Stable identity survives renames, tool swaps and Orca catalogue updates."""
    record=dict(record);key=record.get('library_id') or uuid.uuid4().hex
    record['library_id']=key;record['updated']=time.time()
    if not 2<=len(record.get('name','').strip())<=160 or any(ord(c)<32 for c in record['name']):raise ValueError('Nome: 2-160 caratteri.')
    import re,math
    if not re.fullmatch(r'#[0-9A-Fa-f]{6}',record.get('color','')):raise ValueError('Colore HEX non valido.')
    for field,low,high in [('temp',170,340),('bed',0,110),('flow',.5,1.5),('max_flow',.1,100)]:
        v=record.get(field)
        if not isinstance(v,(float,int)) or not math.isfinite(v) or not low<=v<=high:raise ValueError('Valore non valido: '+field)
    records=library();previous=records.get(key,{})
    record.setdefault('calibrations',previous.get('calibrations',{}))
    records[key]=record;write_json('indx-filament-library.json',{'schema':3,'profiles':records})
    assignments=read_json('indx-filament-assignments.json',{})
    for tool,assigned in assignments.items():
        if assigned.get('library_id')==key:
            assignments[tool]=for_tool(record,int(tool))
    write_json('indx-filament-assignments.json',assignments)
    return record

def assigned(tool):
    a=read_json('indx-filament-assignments.json',{}).get(str(tool))
    if a and a.get('library_id') in library():return for_tool(library()[a['library_id']],tool)
    return a

def for_tool(record,tool):
    r=dict(record,tool=tool,nozzle=NOZZLES[tool],nozzle_type=hardware(tool)['type']);c=calibration(record,tool)
    generic=record.get('generic_base',record.get('profile_id','').startswith('Generic ') or 'Base da calibrare' in record.get('profile_id',''))
    if generic and hardware(tool)['type']=='cht':r['max_flow']=min(100,record.get('max_flow',12)*hardware(tool)['cht_multiplier'])
    settings=record.get('settings_variants',{}).get(nozzle_key(tool),{})
    if not settings and hardware(tool)['type']=='standard' and NOZZLES[tool]==DEFAULT_NOZZLES[tool]:settings=record.get('tool_settings',{}).get(str(tool),{})
    r.update(settings)
    if c.get('nozzle')==NOZZLES[tool]:
        for key in ('flow','max_flow'):
            if key in c:r[key]=c[key]
    return r

def assign_profile(record,tool):
    record=save_profile(record)
    a=read_json('indx-filament-assignments.json',{});a[str(tool)]=for_tool(record,tool)
    write_json('indx-filament-assignments.json',a)
    return a[str(tool)]

def save_calibration(tool,kind,value,name=None,**details):
    import math
    limits={'pa':(0,1),'flow':(.5,1.5),'max_flow':(.1,100)}
    if kind not in limits or not isinstance(value,(int,float)) or not math.isfinite(value) or not limits[kind][0]<=value<=limits[kind][1]:raise ValueError('Risultato fuori intervallo.')
    record=assigned(tool)
    if not record:raise ValueError('Prima salva e assegna un filamento nella pagina Filamenti.')
    record=dict(library().get(record.get('library_id'),record))
    if name:record['name']=name.strip()
    variants=record.setdefault('calibration_variants',{})
    for t,old in record.get('calibrations',{}).items():
        signature=f"{t}:{old['nozzle']:.3f}:{old.get('nozzle_type','standard')}";variants.setdefault(signature,old)
    cal=variants.setdefault(nozzle_key(tool),{'nozzle':NOZZLES[tool],'nozzle_type':hardware(tool)['type']})
    cal[kind]=value;cal[kind+'_test']=dict(details,method='visual-manual',updated=time.time(),temp=record['temp'])
    record.setdefault('calibrations',{})[str(tool)]=cal
    return assign_profile(record,tool)
