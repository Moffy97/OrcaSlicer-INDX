"""Variable-count manual tool selector. Uses only existing, commissioned macros."""
import json
from urllib.request import urlopen
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store

class Panel(ScreenPanel):
 def __init__(self,screen,title):
  super().__init__(screen,title or 'Tool INDX')
  grid=Gtk.Grid(column_spacing=12,row_spacing=12,margin=12)
  self.tool=Gtk.ComboBoxText();grid.attach(self.tool,0,0,2,1)
  for row,(label,command) in enumerate([('Aggancia tool selezionato','CHANGE_TOOL'),('Parcheggia tool attivo','PARK_TOOL')],1):
   b=self._gtk.Button(label=label);b.connect('clicked',self.action,command);grid.attach(b,0,row,2,1)
  self.status=Gtk.Label(label='La lista segue il montaggio dichiarato. Le azioni richiedono macro presenti e collaudo verificato.',wrap=True);grid.attach(self.status,0,3,2,1)
  self.content.add(grid);self.activate()
 def activate(self):
  selected=max(0,self.tool.get_active());self.tool.remove_all()
  for t,d in enumerate(store.NOZZLES):self.tool.append_text(f'T{t} - {d} mm {store.hardware(t)["type"]}')
  self.tool.set_active(min(selected,store.tool_count()-1))
 def action(self,widget,command):
  try:
   with urlopen('http://127.0.0.1:7125/printer/objects/query?gcode_macro%20_INDX_SETUP&gcode_macro%20TOOL_POSITIONS&print_stats',timeout=4) as response:state=json.load(response)['result']['status']
   setup=state.get('gcode_macro _INDX_SETUP',{})
   if not setup.get('geometry_verified') or not setup.get('cleaning_verified'):raise ValueError('Prima completare il collaudo delle macro di geometria e pulizia.')
   if state.get('print_stats',{}).get('state') in ('printing','paused'):raise ValueError('Stampante occupata.')
   hardware=store.read_json('indx-tool-setup.json',{})
   if not hardware.get('confirmed_at') or state.get('gcode_macro TOOL_POSITIONS',{}).get('tool_count')!=store.tool_count():raise ValueError('Conferma il montaggio e verifica il numero tool nelle macro.')
   with urlopen('http://127.0.0.1:7125/printer/objects/list',timeout=4) as response:objects=json.load(response)['result']['objects']
   if 'gcode_macro '+command not in objects:raise ValueError('Macro non disponibile: '+command)
   tool=self.tool.get_active()
   if tool not in range(store.tool_count()):raise ValueError('Tool non disponibile')
   script=command+(' TOOL='+str(tool) if command=='CHANGE_TOOL' else '')
   self._screen._confirm_send_action(widget,'Confermi il movimento con le posizioni dei dock gia collaudate? Area della macchina libera.', 'printer.gcode.script',{'script':script})
  except Exception as e:self.status.set_text(str(e))
