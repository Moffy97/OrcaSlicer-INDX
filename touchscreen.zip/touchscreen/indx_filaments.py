"""Filament selection from the real Orca preset catalog. No printer movements."""
import json, re, time, hashlib, threading
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,GLib
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store
NOZZLES=store.NOZZLES

class Panel(ScreenPanel):
    def __init__(self,screen,title):
        super().__init__(screen,title or 'Filamenti per testa')
        self.loading=False;self.syncing=False;self.catalog_data=store.catalog();self.selected={}
        grid=Gtk.Grid(column_spacing=12,row_spacing=6)
        self.tool=Gtk.ComboBoxText()
        for t,d in enumerate(NOZZLES):self.tool.append_text(f'T{t} - {d} mm')
        self.tool.set_active(0)
        self.search=self.entry('Cerca marca, tipo o nome del profilo')
        self.scope=Gtk.ComboBoxText()
        for name in ['I miei filamenti calibrati','I miei filamenti - tutti','Nuovo da basi Orca','Nuovo da basi personali']:self.scope.append_text(name)
        self.scope.set_active(0 if store.library() else 2)
        self.profiles=Gtk.ComboBoxText();self.profiles.set_hexpand(True)
        self.brand=Gtk.ComboBoxText();self.brand.set_hexpand(True)
        self.product=Gtk.Label(halign=Gtk.Align.START);self.product.set_line_wrap(True)
        self.name=self.entry('Nome da ritrovare nell’elenco')
        self.material=Gtk.ComboBoxText();self.material.set_hexpand(True)
        self.color=self.entry('#FFFFFF');self.color.set_text('#FFFFFF');self.color.set_valign(Gtk.Align.CENTER)
        palette=Gtk.FlowBox();palette.set_selection_mode(Gtk.SelectionMode.NONE);palette.set_min_children_per_line(2);palette.set_max_children_per_line(2)
        for label,value in [('Bianco','#FFFFFF'),('Nero','#000000'),('Rosso','#FF3333'),('Blu','#2255DD'),('Verde','#22AA66'),('Arancio','#FF8800')]:
            button=Gtk.Button(label=label);button.connect('clicked',lambda widget,hex_value:self.color.set_text(hex_value),value);palette.add(button)
        self.temp=Gtk.SpinButton.new_with_range(0,500,1);self.temp.set_value(210)
        self.bed=Gtk.SpinButton.new_with_range(0,150,1);self.bed.set_value(60)
        self.flow=Gtk.SpinButton.new_with_range(.5,1.5,.001);self.flow.set_digits(3);self.flow.set_value(1)
        self.max_flow=Gtk.SpinButton.new_with_range(.1,100,.1);self.max_flow.set_digits(1);self.max_flow.set_value(12)
        for n,(label,w) in enumerate([('Testa',self.tool),('Mostra',self.scope),('Marca',self.brand),('Tipo materiale',self.material),('Cerca profilo',self.search),('Profilo / prodotto',self.profiles),('Base selezionata',self.product),('Colore HEX',self.color),('Ugello C',self.temp),('Piano C',self.bed)]):
            grid.attach(Gtk.Label(label=label,halign=Gtk.Align.START),0,n,1,1);grid.attach(w,1,n,1,1)
        grid.attach(palette,2,7,1,1)
        for row,(label,w) in enumerate([('Flow ratio',self.flow),('Flusso massimo mm3/s',self.max_flow)],10):
            grid.attach(Gtk.Label(label=label,halign=Gtk.Align.START),0,row,1,1);grid.attach(w,1,row,1,1)
        self.sync_btn=self._gtk.Button(label='Sincronizza catalogo da Orca');self.sync_btn.connect('clicked',self.sync)
        grid.attach(self.sync_btn,0,13,2,1)
        self.status=Gtk.Label(label='I tuoi filamenti sono separati dalle basi Orca.',wrap=True);grid.attach(self.status,0,14,2,1)
        b=self._gtk.Button(label='Conferma filamento e scegli nome');b.connect('clicked',self.assign);grid.attach(b,0,15,2,1)
        for col,(label,mode) in enumerate([('Calibra PA','pa'),('Calibra flow','flow'),('Calibra flusso massimo','max_flow')]):
            b=self._gtk.Button(label=label);b.connect('clicked',self.calibrate,mode);grid.attach(b,col,16,1,1)
        self.summary=Gtk.Label(wrap=True,halign=Gtk.Align.START);grid.attach(self.summary,0,17,3,1)
        b=self._gtk.Button(label='Conferma ugelli montati sulla stampante');b.connect('clicked',self.hardware_dialog);grid.attach(b,0,18,3,1)
        self.search.connect('changed',self.filter_profiles);self.scope.connect('changed',self.update_filters)
        self.brand.connect('changed',self.update_filters);self.material.connect('changed',self.filter_profiles)
        self.profiles.connect('changed',self.profile_selected);self.tool.connect('changed',self.load_tool)
        scroll=Gtk.ScrolledWindow();scroll.add(grid);self.content.pack_start(scroll,True,True,0)
        self.update_filters();self.load_tool()
    def entry(self,placeholder):
        w=Gtk.Entry(placeholder_text=placeholder,hexpand=True);w.connect('focus-in-event',self._screen.show_keyboard);return w
    def activate(self):
        self.catalog_data=store.catalog();self.refresh_tools();self.update_filters();self.load_tool()
    def refresh_tools(self):
        active=max(0,self.tool.get_active());self.loading=True;self.tool.remove_all()
        for t,d in enumerate(NOZZLES):self.tool.append_text(f'T{t} - {d} mm {store.hardware(t)["type"]}')
        self.tool.set_active(min(active,len(NOZZLES)-1));self.loading=False
    def update_filters(self,*args):
        if self.loading:return
        scope=self.scope.get_active();brand=self.brand.get_active_id() or '';material=self.material.get_active_id() or ''
        if scope<2:
            values=[(r.get('brand') or 'Generic',r.get('type','')) for r in store.library().values()]
        else:
            values=[(p.get('brand') or 'Generic',p.get('material','')) for p in self.catalog_data['profiles'] if p.get('compatible') and (scope!=3 or p.get('source')=='user')]
        self.loading=True;self.brand.remove_all();self.brand.append('','Tutte le marche')
        brands=sorted({b for b,_ in values},key=str.casefold)
        for b in brands:self.brand.append(b,b)
        brand=brand if brand in brands else '';self.brand.set_active_id(brand)
        self.material.remove_all();self.material.append('','Tutti i materiali')
        materials=sorted({m for b,m in values if m and (not brand or b==brand)},key=str.casefold)
        for m in materials:self.material.append(m,m)
        self.material.set_active_id(material if material in materials else '')
        self.loading=False;self.filter_profiles()
    def select_identity(self,brand,material):
        self.loading=True
        for widget,value in ((self.brand,brand),(self.material,material)):
            if not widget.set_active_id(value):widget.append(value,value);widget.set_active_id(value)
        self.loading=False
    def confirm_name(self):
        parent=self.content.get_toplevel()
        dialog=Gtk.Dialog(title='Nome del filamento',transient_for=parent if isinstance(parent,Gtk.Window) else None,modal=True)
        dialog.add_buttons('Annulla',Gtk.ResponseType.CANCEL,'Salva e assegna',Gtk.ResponseType.OK)
        dialog.set_default_size(520,180)
        box=dialog.get_content_area();box.set_spacing(10);box.set_border_width(16)
        box.add(Gtk.Label(label='Conferma il nome da ritrovare fra i tuoi filamenti. Marca e materiale derivano dal profilo selezionato.',wrap=True))
        entry=self.entry('Nome personale del filamento');entry.set_text(self.name.get_text());box.add(entry)
        dialog.show_all();accepted=dialog.run()==Gtk.ResponseType.OK;name=entry.get_text().strip()
        self._screen.remove_keyboard();dialog.destroy()
        return name if accepted else None
    def filter_profiles(self,*args):
        if self.loading:return
        selected=self.profiles.get_active_id();needle=self.search.get_text().casefold();scope=self.scope.get_active()
        brand=self.brand.get_active_id() or '';material=self.material.get_active_id() or ''
        self.loading=True;self.profiles.remove_all()
        if scope<2:
            for key,r in sorted(store.library().items(),key=lambda item:item[1]['name'].casefold()):
                c=store.calibration(r,self.tool.get_active());done=[k for k in ('pa','flow','max_flow') if k in c]
                if scope==0 and not done:continue
                if brand and (r.get('brand') or 'Generic')!=brand:continue
                if material and r.get('type','')!=material:continue
                if needle and needle not in (r['name']+' '+r.get('brand','')+' '+r.get('type','')).casefold():continue
                self.profiles.append('library:'+key,r['name']+' | '+('/'.join(done) if done else 'da calibrare')+(' OK' if len(done)==3 else ''))
        for p in self.catalog_data['profiles']:
            if scope<2 or not p.get('compatible'):continue
            if scope==3 and p.get('source')!='user':continue
            if brand and (p.get('brand') or 'Generic')!=brand:continue
            if material and p.get('material','')!=material:continue
            label=('Personale | ' if p.get('source')=='user' else '')+p['name']
            if needle and needle not in (label+' '+p.get('brand','')+' '+p.get('material','')).casefold():continue
            self.profiles.append(p['id'],label)
        if not selected or not self.profiles.set_active_id(selected):
            self.selected={};self.product.set_text('');self.name.set_text('')
        self.loading=False
    def profile_selected(self,*args):
        if self.loading:return
        key=self.profiles.get_active_id()
        if key and key.startswith('library:'):
            self.fill_saved(store.for_tool(store.library()[key[8:]],self.tool.get_active()));return
        self.selected=next((p for p in self.catalog_data['profiles'] if p['id']==key),{})
        if not self.selected:return
        p=self.selected;c=p['config'];self.select_identity(p.get('brand') or 'Generic',p.get('material',''))
        product=p['name'].split(' @')[0]
        brand=p.get('brand') or 'Generic'
        if product.casefold().startswith(brand.casefold()+' '):product=product[len(brand):].strip()
        self.product.set_text(product)
        self.name.set_text((brand+' '+product).strip())
        self.flow.set_value(store.number(c,'filament_flow_ratio',1));self.max_flow.set_value(store.number(c,'filament_max_volumetric_speed',12))
        self.temp.set_value(store.number(c,'nozzle_temperature',210));self.bed.set_value(store.number(c,'hot_plate_temp',60))
        value=store.first(c,'filament_colour','#FFFFFF');self.color.set_text(value if isinstance(value,str) and re.fullmatch(r'#[0-9A-Fa-f]{6}',value) else '#FFFFFF')
        self.status.set_text(('Profilo compatibile. ' if p.get('compatible') else 'Profilo per altre stampanti: crea in Orca una copia compatibile INDX. ')+p['name'])
    def load_tool(self,*args):
        if self.loading:return
        t=self.tool.get_active();r=store.assigned(t);self.filter_profiles()
        if r and r.get('library_id'):
            self.fill_saved(r);self.refresh_summary();return
        if r and r.get('profile_id'):
            # Assigned profiles remain findable even if the current search/filter hides them.
            self.loading=True;self.search.set_text('');self.scope.set_active(1);self.loading=False;self.filter_profiles()
            self.profiles.set_active_id(r['profile_id'])
            self.select_identity(r.get('brand') or 'Generic',r.get('type',''));self.product.set_text(r.get('product',r['name']))
            self.color.set_text(r.get('color','#FFFFFF'));self.temp.set_value(r['temp']);self.bed.set_value(r['bed'])
            pa=store.resolve_pa(r,t,store.read_json('indx-pa-results.json',{}))
            self.status.set_text(f"T{t}: {r['name']} - "+(f'PA INDX {pa:.4f}' if pa is not None else 'PA INDX non calibrato; Orca usera il PA del profilo'))
        else:
            self.profiles.set_active(-1);self.selected={};self.select_identity('','');self.product.set_text('')
            self.status.set_text(f'T{t}: scegli il profilo Orca del filamento caricato. Nessun movimento viene eseguito.')
        self.refresh_summary()
    def fill_saved(self,r):
        self.loading=True;self.scope.set_active(1);self.search.set_text('');self.loading=False
        self.select_identity(r.get('brand') or 'Generic',r.get('type',''))
        self.update_filters();self.loading=True
        self.profiles.set_active_id('library:'+r['library_id']);self.loading=False
        self.selected=dict(r,from_library=True)
        for widget,key in [(self.product,'product'),(self.name,'name'),(self.color,'color')]:widget.set_text(r.get(key,''))
        self.select_identity(r.get('brand') or 'Generic',r.get('type',''))
        for widget,key,default in [(self.temp,'temp',210),(self.bed,'bed',60),(self.flow,'flow',1),(self.max_flow,'max_flow',12)]:widget.set_value(r.get(key,default))
        self.status.set_text('Profilo personale: '+r['name']+'\n'+store.calibration_summary(r,self.tool.get_active()))
    def refresh_summary(self):
        a=store.read_json('indx-filament-assignments.json',{});results=store.read_json('indx-pa-results.json',{})
        self.summary.set_text('\n'.join(f"T{t} ({NOZZLES[t]} {store.hardware(t)['type']}): "+(store.assigned(t)['name']+' | '+store.calibration_summary(store.assigned(t),t) if str(t) in a else 'non assegnato') for t in range(store.tool_count())))
    def hardware_dialog(self,*args):
        chooser=Gtk.Dialog(title='Numero tool montati',transient_for=self._screen,modal=True)
        chooser.add_buttons('Annulla',Gtk.ResponseType.CANCEL,'Continua',Gtk.ResponseType.OK)
        count=Gtk.SpinButton.new_with_range(1,store.MAX_TOOLS,1);count.set_value(store.tool_count())
        chooser.get_content_area().add(count);chooser.show_all()
        accepted=chooser.run()==Gtk.ResponseType.OK;n=count.get_value_as_int();chooser.destroy()
        if not accepted:return
        dialog=Gtk.Dialog(title='Ugelli realmente montati',transient_for=self._screen,modal=True)
        dialog.set_default_size(650,450)
        dialog.add_buttons('Annulla',Gtk.ResponseType.CANCEL,'Confermo il montaggio',Gtk.ResponseType.OK)
        grid=Gtk.Grid(column_spacing=12,row_spacing=10,margin=12);controls=[]
        for t in range(n):
            h=store.hardware(t) if t<store.tool_count() else dict(tool=t,diameter=.4,type='standard',cht_multiplier=1.3);d=Gtk.SpinButton.new_with_range(.1,2,.01);d.set_digits(2);d.set_value(h['diameter'])
            kind=Gtk.ComboBoxText();kind.append_text('standard');kind.append_text('cht');kind.set_active(h['type']=='cht')
            grid.attach(Gtk.Label(label=f'T{t} diametro mm'),0,t,1,1);grid.attach(d,1,t,1,1);grid.attach(kind,2,t,1,1);controls.append((d,kind))
        grid.attach(Gtk.Label(label='Dichiara solo gli ugelli fisicamente montati.\nLa sincronizzazione Orca non modifica questa dichiarazione.',wrap=True),0,n,3,1)
        scroll=Gtk.ScrolledWindow();scroll.add(grid);dialog.get_content_area().add(scroll);dialog.show_all()
        if dialog.run()==Gtk.ResponseType.OK:
            try:
                store.confirm_hardware([dict(tool=t,diameter=d.get_value(),type=k.get_active_text(),cht_multiplier=store.hardware(t)['cht_multiplier'] if t<store.tool_count() else 1.3) for t,(d,k) in enumerate(controls)])
                self.refresh_tools();self.load_tool();self.status.set_text('Montaggio dichiarato. In Orca usa Controlla prima di stampare.')
            except Exception as e:self.status.set_text(str(e))
        dialog.destroy()
    def sync(self,*args):
        if self.syncing:return
        self._screen.remove_keyboard();self.syncing=True;self.sync_btn.set_sensitive(False)
        self.status.set_text('Richiedo a Orca i profili standard e personali aggiornati...')
        def work():
            try:result=store.refresh_catalog();GLib.idle_add(self.sync_done,result,None)
            except Exception as e:GLib.idle_add(self.sync_done,None,str(e))
        threading.Thread(target=work,daemon=True).start()
    def sync_done(self,result,error):
        self.syncing=False;self.sync_btn.set_sensitive(True)
        if error:self.status.set_text(error);return False
        self.catalog_data=result;self.refresh_tools();self.update_filters();self.load_tool()
        profiles=result['profiles'];personal=sum(p.get('source')=='user' for p in profiles)
        self.status.set_text(f"Importati {len(profiles)} profili: {len(profiles)-personal} standard, {personal} personali. Usa la ricerca e il filtro.")
        return False
    def assign(self,*args):
        self._screen.remove_keyboard()
        try:
            p=self.selected
            if not p:raise ValueError('Seleziona un profilo Orca.')
            if not p.get('from_library') and not p.get('compatible'):raise ValueError('Profilo per altre stampanti. Prima salva in Orca una copia compatibile con SV08 Max INDX.')
            brand=p.get('brand') or 'Generic';product=self.product.get_text().strip()
            if not product:raise ValueError('Seleziona un profilo dall elenco.')
            color=self.color.get_text().upper()
            if not re.fullmatch(r'#[0-9A-F]{6}',color):raise ValueError('Colore: es. #FFFFFF.')
            temp=self.temp.get_value_as_int();bed=self.bed.get_value_as_int()
            if not 170<=temp<=340 or not 0<=bed<=110:raise ValueError('Temperature supportate dal profilo attuale: ugello 170-340 C, piano 0-110 C.')
            name=self.confirm_name()
            if name is None:return
            if not 2<=len(name)<=160 or any(ord(c)<32 for c in name):raise ValueError('Nome: da 2 a 160 caratteri, senza caratteri di controllo.')
            self.name.set_text(name)
            t=self.tool.get_active()
            r=dict(store.library().get(p.get('library_id'),p)) if p.get('from_library') else dict(profile_id=p['id'],profile_name=p['name'],profile_revision=p.get('revision',''),base='orca:'+p['id'],type=p.get('material',''),generic_base=p.get('generic',p['id'].startswith('Generic ') or 'Base da calibrare' in p['id']),calibrations={})
            r.pop('from_library',None)
            r.update(name=name,brand=brand,product=product,color=color,temp=temp,bed=bed)
            r.setdefault('flow',self.flow.get_value());r.setdefault('max_flow',self.max_flow.get_value())
            c=store.calibration_raw(r,t)
            settings=r.setdefault('settings_variants',{}).setdefault(store.nozzle_key(t),{})
            for field,widget in [('flow',self.flow),('max_flow',self.max_flow)]:
                value=widget.get_value();settings[field]=value
                if field in c and abs(c[field]-value)>1e-6:c[field+'_invalidated']='Valore modificato manualmente dopo il test'
            r=store.assign_profile(r,t);self.selected=dict(r,from_library=True)
            pa=store.resolve_pa(r,t,store.read_json('indx-pa-results.json',{}))
            self.status.set_text(f"T{t}: {name}. "+(f'PA INDX {pa:.4f}.' if pa is not None else 'PA INDX non calibrato: resta disponibile il PA del profilo Orca.'))
            self.refresh_summary()
        except Exception as e:self.status.set_text(str(e))
    def calibrate(self,widget,mode='pa'):
        if not store.assigned(self.tool.get_active()):self.status.set_text('Prima salva e assegna un filamento.');return
        self._screen.show_panel('indx_pa' if mode=='pa' else 'indx_flow',title='Calibra '+mode,tool=self.tool.get_active(),**({} if mode=='pa' else {'mode':mode}))
