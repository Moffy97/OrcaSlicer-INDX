"""Deterministic visual calibration specimens. No dependency on GTK or Orca."""
import math

NOZZLES=(.4,.4,.6,.8)
FILAMENT_AREA=math.pi*(1.75/2)**2

def area(width,height):
    return height*(width-height)+math.pi*(height/2)**2

def max_flow_layer_height(nozzle):
    return 1.2/math.ceil(1.2/min(.4,nozzle/2))

def begin(tool,temp,bed,fan,old_pa):
    if not isinstance(tool,int) or tool not in range(64) or not 170<=temp<=340 or not 0<=bed<=110 or not 0<=fan<=100:raise ValueError('Parametri test non validi')
    if not math.isfinite(old_pa) or not 0<=old_pa<=1:raise ValueError('PA non valido')
    return ['; INDX calibration - inspect visually; no automatic measurement',
            '_INDX_REQUIRE_COMMISSIONED',f'INDX_PRINT_START TOOL={tool} EXTRUDER={int(temp)} BED={int(bed)}',
            'G90','M83','G92 E0','M220 S100','M221 S100',f'SET_PRESSURE_ADVANCE ADVANCE={old_pa:.5f}',
            f'M106 S{round(fan*255/100)}','G1 Z5 F600']

def finish(lines,old_pa,old_flow=1,old_speed=1):
    if not .1<=old_flow<=3 or not .1<=old_speed<=3:raise ValueError('Fattori stampante fuori intervallo')
    lines+=['G1 E-0.5 F1800','G91','G1 Z5 F600','G90',f'SET_PRESSURE_ADVANCE ADVANCE={old_pa:.5f}',
            'INDX_PRINT_END',f'M221 S{old_flow*100:.3f}',f'M220 S{old_speed*100:.3f}']
    return '\n'.join(lines)+'\n'

def flow_test(tool,temp,bed,base,step=.02,fan=100,old_pa=0,old_flow=1,old_speed=1,nozzle=None):
    """Seven 18 mm solid coupons, numbered left-to-right then rear row.

    Five .2 mm layers, orthogonal rectilinear fill. Rounded bead cross-section
    matches Orca extrusion math; multiplier changes material only, not spacing.
    """
    if not .5<=base<=1.5 or step not in (.01,.02):raise ValueError('Flow o passo non valido')
    values=[round(base*(1+(i-3)*step),5) for i in range(7)]
    if min(values)<.5 or max(values)>1.5:raise ValueError('Intervallo flow fuori limite .5-1.5')
    if nozzle is None and tool not in range(len(NOZZLES)):raise ValueError('Specificare il diametro del tool')
    nozzle=NOZZLES[tool] if nozzle is None else nozzle
    if not .1<=nozzle<=2:raise ValueError('Diametro ugello fuori intervallo')
    width=nozzle*1.05;height=min(.2,nozzle/2);spacing=width-height*(1-math.pi/4)
    lines=begin(tool,temp,bed,fan,old_pa)
    for layer in range(math.ceil(1/height)):
        z=(layer+1)*height
        for i,ratio in enumerate(values):
            x=130+(i%4)*25;y=145+(i//4)*28;side=18
            lines += [f'; CAMPIONE {i+1} flow={ratio:.5f} layer={layer+1}', 'G1 Z3 F600' if layer==0 else f'G1 Z{z+.5:.3f} F600',
                      f'G1 X{x:.3f} Y{y:.3f} F6000',f'G1 Z{z:.3f} F600']
            speed=min(20 if layer==0 else 40,8/(area(width,height)*ratio))
            pos=[x,y]
            def move(nx,ny):
                length=math.hypot(nx-pos[0],ny-pos[1]);e=length*area(width,height)*ratio/FILAMENT_AREA
                lines.append(f'G1 X{nx:.3f} Y{ny:.3f} E{e:.5f} F{speed*60:.1f}');pos[:]=[nx,ny]
            for nx,ny in [(x+side,y),(x+side,y+side),(x,y+side),(x,y)]:move(nx,ny)
            # Fill inside the perimeter with alternating, overlapping lines.
            count=max(2,math.ceil((side-2*spacing)/spacing));delta=(side-2*spacing)/(count-1)
            for n in range(count):
                if layer%2==0:
                    a=(x+spacing,y+spacing+n*delta);b=(x+side-spacing,a[1])
                else:
                    a=(x+spacing+n*delta,y+spacing);b=(a[0],y+side-spacing)
                if n%2:a,b=b,a
                move(*a);move(*b)
    return finish(lines,old_pa,old_flow,old_speed),values

def max_flow_test(tool,temp,bed,ratio,start=5,end=25,step=2,fan=100,old_pa=0,old_flow=1,old_speed=1,nozzle=None):
    """Single-wall 100 x 20 mm tower: each numbered band is 1.2 mm tall.

    Displayed Q includes the calibrated flow ratio; base is printed slowly.
    User picks the last clean band; panel stores 90% of that tested Q.
    """
    if nozzle is None and tool not in range(len(NOZZLES)):raise ValueError('Specificare il diametro del tool')
    nozzle=NOZZLES[tool] if nozzle is None else nozzle
    if not .1<=nozzle<=2:raise ValueError('Diametro ugello fuori intervallo')
    h=max_flow_layer_height(nozzle);w=nozzle*1.1
    cross=area(w,h)*ratio
    if not .5<=ratio<=1.5 or not .2<=start<end<=60 or not .1<=step<=5:raise ValueError('Intervallo test non valido')
    bands=math.floor((end-start)/step)+1
    if bands>30:raise ValueError('Massimo 30 fasce; aumenta il passo')
    if end/cross>300:raise ValueError(f'Portata troppo alta per questo ugello: massimo {cross*300:.1f} mm3/s nel test (300 mm/s).')
    qs=[round(start+n*step,3) for n in range(bands)]
    lines=begin(tool,temp,bed,fan,old_pa)+['G1 X130 Y145 F6000']
    z=0
    layers=max(1,round(1.2/h))
    for band in range(-1,bands):
        q=min(3,qs[0]) if band<0 else qs[band]
        for layer in range(layers if band>=0 else 3):
            z+=h
            lines += [f'; FASCIA {band+1} Q={q:.3f} Z={z:.3f}',f'G1 Z{z:.3f} F600']
            speed=q/cross
            for x,y,length in [(230,145,100),(230,165,20),(130,165,100),(130,145,20)]:
                lines.append(f'G1 X{x} Y{y} E{length*cross/FILAMENT_AREA:.5f} F{speed*60:.1f}')
    return finish(lines,old_pa,old_flow,old_speed),qs
