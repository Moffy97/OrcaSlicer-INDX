"""INDX Studio overview, persistent navigation and lazy touch pages."""
import importlib
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store, indx_ui as ui

PAGES=[('Panoramica','overview'),('Filamenti','indx_filaments'),('Tool e dock','indx_machine_panel'),('Pressure advance','indx_pa'),('Flow ratio','indx_flow'),('Portata massima','indx_max_flow'),('Collaudo','indx_setup'),('Cambia tool','indx_tools')]
DESCRIPTIONS={'overview':'Tool, filamenti e calibrazioni a colpo d’occhio.', 'indx_filaments':'Scegli marca e materiale. Salva la tua bobina e ritrovala in Orca.', 'indx_machine_panel':'Ugelli, dock e offset del montaggio reale.', 'indx_pa':'Stampa il test, scegli la riga migliore e salva il PA.', 'indx_flow':'Regola la quantità estrusa per questo filamento e ugello.', 'indx_max_flow':'Misura la portata utile del filamento su questo ugello.', 'indx_setup':'Completa le verifiche prima della prima stampa.', 'indx_tools':'Aggancio e parcheggio con conferma del movimento.'}
class Proxy:
 def __init__(self,screen,dashboard):self.screen=screen;self.dashboard=dashboard
 def __getattr__(self,key):return getattr(self.screen,key)
 def show_panel(self,name,*args,**kwargs):
  panel=kwargs.get('panel_name',kwargs.get('panel',name))
  if panel=='indx_flow' and kwargs.get('mode')=='max_flow':panel='indx_max_flow'
  if panel in self.dashboard.locations:self.dashboard.goto(panel,kwargs.get('tool'))
  else:self.screen.show_panel(name,*args,**kwargs)

class Panel(ScreenPanel):
 def __init__(self,screen,title):
  super().__init__(screen,title or 'INDX Studio');self.tabs=Gtk.Box(orientation=Gtk.Orientation.VERTICAL);self.visible_name='overview';self.panels={};self.holders={};self.locations={name:i for i,(_,name) in enumerate(PAGES)};self.selected_tool=0;self.selecting=False;self.destroyed=False;self.proxy=Proxy(screen,self)
  ui.style(self.content,'indx-workspace')
  self.content.connect('destroy',self.on_destroy)
  shell=Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL,spacing=14)
  navigation=ui.style(Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=2),'indx-sidebar');navigation.set_size_request(180,-1);self.navigation=[]
  navigation.pack_start(ui.label('INDX','indx-heading'),False,False,6);navigation.pack_start(ui.label('SV08 MAX · STUDIO','indx-muted'),False,False,4)
  for label,name in PAGES:
   button=ui.button(label,self.navigate,name);navigation.pack_start(button,False,False,0);self.navigation.append(button)
  shell.pack_start(ui.scroll(navigation),False,False,0)
  body=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=8);self.heading=ui.label('Panoramica','indx-heading');self.description=ui.label(DESCRIPTIONS['overview'],'indx-muted')
  body.pack_start(self.heading,False,False,0);body.pack_start(self.description,False,False,0);body.pack_start(self.tabs,True,True,0);shell.pack_start(body,True,True,0);self.content.pack_start(shell,True,True,0)
  self.overview=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=12);self.holders['overview']=ui.scroll(self.overview);self.tabs.pack_start(self.holders['overview'],True,True,0);self.selected()
 def overview_refresh(self):
  for child in self.overview.get_children():self.overview.remove(child)
  confirmed=bool(store.read_json('indx-tool-setup.json',{}).get('confirmed_at'))
  status=ui.card('Montaggio confermato' if confirmed else 'Montaggio da confermare',f'{store.tool_count()} tool configurati · Calibrazioni per filamento e ugello.')
  status.pack_start(ui.label('Nessun movimento aprendo questa schermata.','indx-muted'),False,False,0);self.overview.pack_start(status,False,False,0)
  cards=Gtk.Grid(column_homogeneous=True,column_spacing=12,row_spacing=12)
  for t,d in enumerate(store.NOZZLES):
   record=store.assigned(t);hw=store.hardware(t);box=ui.card(f'T{t}    {d:g} mm  ·  {hw["type"].upper()}')
   box.pack_start(ui.label(record.get('name','Filamento senza nome') if record else 'Nessun filamento assegnato','indx-section'),False,False,0)
   if record:
    box.pack_start(ui.label(' · '.join(str(record.get(k,'')) for k in ('brand','type','color')),'indx-muted'),False,False,0)
    c=store.calibration(record,t);badges='   '.join(label+(' ✓' if key in c else ' —') for key,label in [('pa','PA'),('flow','FLOW'),('max_flow','PORTATA')])
   else:badges='PA —    FLOW —    PORTATA —'
   box.pack_start(ui.label(badges,'indx-badge'),False,False,0);box.pack_start(ui.button('Scegli filamento',self.open_filament,t),False,False,0);cards.attach(box,t%2,t//2,1,1)
  self.overview.pack_start(cards,False,False,0);self.overview.show_all()
 def open_filament(self,widget,t):self.goto('indx_filaments',t)
 def ensure(self,name):
  if name=='overview':return None
  if name not in self.panels:
   self.holders[name]=Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
   label=PAGES[self.locations[name]][0];p=importlib.import_module('panels.'+name).Panel(self.proxy,label);self.panels[name]=p
   if hasattr(p,'tool'):p.tool.connect('changed',self.tool_changed)
   ui.style(p.content,'indx-page');ui.prepare(p.content)
   if hasattr(p,'status'):p.status.set_halign(Gtk.Align.FILL);p.status.set_hexpand(True);p.status.set_xalign(0)
   self.holders[name].pack_start(p.content,True,True,0);p.content.show_all()
  return self.panels[name]
 def navigate(self,widget,name):
  if not self.selecting and not self.destroyed:self.goto(name)
 def activate(self):self.selected()
 def selected(self,*args):
  if self.destroyed:return
  name=self.visible_name;self.selecting=True
  for (_,key),button in zip(PAGES,self.navigation):button.get_style_context().add_class('suggested-action') if key==name else button.get_style_context().remove_class('suggested-action')
  self.selecting=False;self.heading.set_text(PAGES[self.locations[name]][0]);self.description.set_text(DESCRIPTIONS[name])
  if name=='overview':self.overview_refresh();return
  p=self.ensure(name);chosen=self.selected_tool;p.activate()
  if hasattr(p,'tool') and chosen<p.tool.get_model().iter_n_children(None):p.tool.set_active(chosen)
 def tool_changed(self,widget):
  if widget.get_active()>=0:self.selected_tool=widget.get_active()
 def goto(self,name,tool=None):
  if tool is not None:self.selected_tool=tool
  self.ensure(name)
  if self.visible_name!=name:
   self.tabs.remove(self.holders[self.visible_name]);self.visible_name=name;self.tabs.pack_start(self.holders[name],True,True,0);self.holders[name].show_all()
  self.selected()
 def on_destroy(self,*args):self.destroyed=True
