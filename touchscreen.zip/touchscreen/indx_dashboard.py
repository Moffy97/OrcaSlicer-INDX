"""Direct selection buttons and lazily constructed INDX pages."""
import importlib
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk
from ks_includes.screen_panel import ScreenPanel

PAGES=[('Tool e dock','indx_machine_panel'),('Filamenti','indx_filaments'),('PA','indx_pa'),('Flow','indx_flow'),('Portata','indx_max_flow'),('Collaudo','indx_setup'),('Tool attivo','indx_tools')]
class Proxy:
 def __init__(self,screen,dashboard):self.screen=screen;self.dashboard=dashboard
 def __getattr__(self,key):return getattr(self.screen,key)
 def show_panel(self,name,*args,**kwargs):
  panel=kwargs.get('panel_name',kwargs.get('panel',name))
  if panel=='indx_flow' and kwargs.get('mode')=='max_flow':panel='indx_max_flow'
  if panel in self.dashboard.locations:self.dashboard.goto(panel,kwargs.get('tool'))
  else:self.screen.show_panel(name,*args,**kwargs)

class Panel(ScreenPanel):
 def __init__(self,screen,title):
  super().__init__(screen,title or 'INDX');self.tabs=Gtk.Box(orientation=Gtk.Orientation.VERTICAL);self.visible_name='indx_machine_panel';self.panels={};self.holders={};self.locations={name:i for i,(_,name) in enumerate(PAGES)};self.selected_tool=0;self.selecting=False;self.destroyed=False;self.proxy=Proxy(screen,self)
  self.content.connect('destroy',self.on_destroy)
  navigation=Gtk.Grid(column_homogeneous=True,column_spacing=4,row_spacing=4);self.navigation=[]
  for label,name in PAGES:
   holder=Gtk.Box(orientation=Gtk.Orientation.VERTICAL);holder.show();self.holders[name]=holder;self.tabs.pack_start(holder,True,True,0) if name==self.visible_name else None
   button=Gtk.Button(label=label);button.set_size_request(130,46);button.connect('clicked',self.navigate,name);navigation.attach(button,len(self.navigation)%4,len(self.navigation)//4,1,1);self.navigation.append(button)
  self.ensure('indx_machine_panel');self.selecting=True;self.navigation[0].get_style_context().add_class('suggested-action');self.selecting=False
  self.content.pack_start(navigation,False,False,4);self.content.pack_start(self.tabs,True,True,0)
 def ensure(self,name):
  if name not in self.panels:
   label=PAGES[self.locations[name]][0];p=importlib.import_module('panels.'+name).Panel(self.proxy,label);self.panels[name]=p
   if hasattr(p,'tool'):p.tool.connect('changed',self.tool_changed)
   self.holders[name].pack_start(p.content,True,True,0);p.content.show_all()
  return self.panels[name]
 def navigate(self,widget,name):
  if not self.selecting and not self.destroyed:self.goto(name)
 def activate(self):self.selected()
 def selected(self,*args):
  if self.destroyed:return
  name=self.visible_name;self.selecting=True
  for (_,key),button in zip(PAGES,self.navigation):button.get_style_context().add_class('suggested-action') if key==name else button.get_style_context().remove_class('suggested-action')
  self.selecting=False;p=self.ensure(name);chosen=self.selected_tool;p.activate()
  if hasattr(p,'tool') and chosen<p.tool.get_model().iter_n_children(None):p.tool.set_active(chosen)
 def tool_changed(self,widget):
  if widget.get_active()>=0:self.selected_tool=widget.get_active()
 def goto(self,name,tool=None):
  if tool is not None:self.selected_tool=tool
  self.ensure(name)
  if self.visible_name!=name:
   self.tabs.remove(self.holders[self.visible_name]);self.visible_name=name;self.tabs.pack_start(self.holders[name],True,True,0);self.holders[name].show_all()
  self.selected()
 def on_destroy(self,*args):self.destroyed=True
