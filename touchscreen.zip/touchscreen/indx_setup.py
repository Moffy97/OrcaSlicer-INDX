"""Guided manual commissioning, independent of Klipper's movement gates."""
import json,threading
from urllib.request import urlopen
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,GLib
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store
from panels import indx_commissioning as guide

class Panel(ScreenPanel):
 def __init__(self,screen,title):
  super().__init__(screen,title or 'Collaudo INDX')
  grid=Gtk.Grid(column_spacing=12,row_spacing=10,margin=12)
  grid.attach(Gtk.Label(label='INDX preview 0.3.0\nChecklist manuale: non esegue movimenti e non abilita le macro di collaudo.',wrap=True),0,0,2,1)
  self.step=Gtk.ComboBoxText()
  for key,label,_ in guide.STEPS:self.step.append(key,label)
  self.step.set_active(0);grid.attach(self.step,0,1,2,1)
  self.instructions=Gtk.Label(wrap=True,halign=Gtk.Align.START);grid.attach(self.instructions,0,2,2,1)
  self.done=Gtk.CheckButton(label='Passaggio verificato fisicamente');grid.attach(self.done,0,3,2,1)
  self.notes=Gtk.Entry(placeholder_text='Quote, misure e note del collaudo',hexpand=True);self.notes.connect('focus-in-event',self._screen.show_keyboard);grid.attach(self.notes,0,4,2,1)
  b=self._gtk.Button(label='Salva passaggio');b.connect('clicked',self.save);grid.attach(b,0,5,1,1)
  self.refresh=self._gtk.Button(label='Leggi stato Klipper');self.refresh.connect('clicked',self.read_state);grid.attach(self.refresh,1,5,1,1)
  self.status=Gtk.Label(wrap=True,halign=Gtk.Align.START);grid.attach(self.status,0,6,2,1)
  self.progress=Gtk.Label(wrap=True,halign=Gtk.Align.START);grid.attach(self.progress,0,7,2,1)
  scroll=Gtk.ScrolledWindow();scroll.add(grid);self.content.pack_start(scroll,True,True,0)
  self.step.connect('changed',self.load);self.load()
 def data(self):return guide.checklist(store.read_json('indx-commissioning.json',{}),store.read_json('indx-tool-setup.json',{}))
 def activate(self):self.load()
 def load(self,*args):
  key=self.step.get_active_id();data=self.data();row=next(s for s in guide.STEPS if s[0]==key);saved=data['steps'].get(key,{})
  self.instructions.set_text(row[2]);self.done.set_active(saved.get('done',False));self.notes.set_text(saved.get('notes',''))
  self.progress.set_text('\n'.join(('OK - ' if data['steps'].get(k,{}).get('done') else 'Da verificare - ')+label for k,label,_ in guide.STEPS))
 def save(self,*args):
  self._screen.remove_keyboard()
  try:
   data=guide.save_step(self.data(),store.read_json('indx-tool-setup.json',{}),self.step.get_active_id(),self.done.get_active(),self.notes.get_text())
   store.write_json('indx-commissioning.json',data);self.load();self.status.set_text('Checklist salvata. Le macro di movimento restano indipendenti.')
  except Exception as e:self.status.set_text(str(e))
 def read_state(self,*args):
  self.refresh.set_sensitive(False)
  def work():
   try:
    with urlopen('http://127.0.0.1:7125/printer/objects/query?gcode_macro%20_INDX_SETUP&gcode_macro%20TOOL_POSITIONS&print_stats',timeout=4) as response:data=json.load(response)['result']['status']
    c=data.get('gcode_macro _INDX_SETUP',{});n=data.get('gcode_macro TOOL_POSITIONS',{}).get('tool_count','non disponibile')
    message=f"Macro: geometria={c.get('geometry_verified',False)}, pulizia={c.get('cleaning_verified',False)}; tool={n}. Stato stampa: {data.get('print_stats',{}).get('state','sconosciuto')}."
   except Exception as e:message='Lettura non riuscita: '+str(e)
   GLib.idle_add(self.state_done,message)
  threading.Thread(target=work,daemon=True).start()
 def state_done(self,message):self.refresh.set_sensitive(True);self.status.set_text(message);return False
