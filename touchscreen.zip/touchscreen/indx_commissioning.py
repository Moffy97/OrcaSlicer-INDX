"""Recorded commissioning checklist. Never changes firmware or motion gates."""
import hashlib,json,time
STEPS=[
 ('connection','Collegamenti e montaggio','Verifica alimentazione, USB, cablaggio finecorsa e cella seguendo il manuale della tua integrazione.'),
 ('docks','Dock e corsie','Misura ogni dock e le corsie libere, controlla limiti e ingombri. Non usare quote di esempio come misure reali.'),
 ('pickup','Aggancio e sgancio','Collauda ciascun tool con la procedura ufficiale, controllando fermo, presenza tool e assenza di collisioni.'),
 ('cleaning','Pulizia ugello','Verifica separatamente tastatura, sollevamento, spostamento e passate. Conserva le quote effettivamente provate.'),
 ('z','Offset Z','Usa la procedura ufficiale con la cella e ugello pulito. Registra offset e ripetibilita per ogni tool.'),
 ('xy','Offset XY','Esegui il test di allineamento con un tool di riferimento; misura e verifica gli offset di ogni altro tool.'),
 ('print','Stampa di collaudo','Prova un modello semplice con tutti i tool previsti e controlla cambi, temperature e primo strato.')]

def signature(hardware):
 return hashlib.sha256(json.dumps(hardware.get('tools',[]),sort_keys=True).encode()).hexdigest()

def checklist(saved,hardware):
 if saved.get('hardware_key')!=signature(hardware):return {'schema':1,'hardware_key':signature(hardware),'steps':{}}
 return saved

def save_step(saved,hardware,key,done,notes):
 result=checklist(saved,hardware)
 ids=[s[0] for s in STEPS]
 if key not in ids:raise ValueError('Passaggio sconosciuto')
 index=ids.index(key)
 if done and any(not result['steps'].get(k,{}).get('done') for k in ids[:index]):raise ValueError('Completa prima i passaggi precedenti')
 result['steps'][key]={'done':bool(done),'notes':str(notes)[:4000],'updated':time.time()}
 if not done:
  for k in ids[index+1:]:
   if k in result['steps']:result['steps'][k]['done']=False
 return result
