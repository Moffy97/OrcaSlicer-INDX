"""Touchscreen flow ratio and volumetric flow calibration, visually evaluated."""
import json,time
from pathlib import Path
from urllib.request import urlopen
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store
from panels import indx_flow_tests as tests

class Panel(ScreenPanel):
    def __init__(self,screen,title,tool=0,mode='flow'):
        super().__init__(screen,title or 'Calibrazione filamento')
        self.mode=mode;self.run=None
        grid=Gtk.Grid(column_spacing=12,row_spacing=8)
        self.tool=Gtk.ComboBoxText()
        for t,d in enumerate(store.NOZZLES):self.tool.append_text(f'T{t} - {d} mm')
        self.tool.set_active(tool)
        self.name=Gtk.Entry(hexpand=True);self.name.connect('focus-in-event',self._screen.show_keyboard)
        self.fine=Gtk.CheckButton(label='Passo fine 1% (normale 2%)')
        self.start=self.spin(.2,50,.1,5);self.end=self.spin(.3,60,.1,25);self.step=self.spin(.1,5,.1,2)
        self.fan=self.spin(0,100,5,100);self.choice=self.spin(1,30,1,1)
        self.info=Gtk.Label(wrap=True,halign=Gtk.Align.START)
        widgets=[('Testa',self.tool),('Salva col nome',self.name),('Ventola %',self.fan)]
        if mode=='flow':widgets += [('Precisione',self.fine)]
        else:widgets += [('Inizio mm3/s',self.start),('Fine mm3/s',self.end),('Passo mm3/s',self.step)]
        widgets += [('Campione migliore' if mode=='flow' else 'Ultima fascia senza difetti',self.choice)]
        for row,(label,w) in enumerate(widgets):
            grid.attach(Gtk.Label(label=label,halign=Gtk.Align.START),0,row,1,1);grid.attach(w,1,row,1,1)
        row=len(widgets);grid.attach(self.info,0,row,2,1)
        self.status=Gtk.Label(wrap=True);grid.attach(self.status,0,row+1,2,1)
        for col,(label,cb) in enumerate([('Stampa test',self.test),('Salva nel mio profilo',self.save)]):
            b=self._gtk.Button(label=label);b.connect('clicked',cb);grid.attach(b,col,row+2,1,1)
        scroll=Gtk.ScrolledWindow();scroll.add(grid);self.content.add(scroll)
        self.tool.connect('changed',self.load);self.load()
    def spin(self,low,high,step,value):
        s=Gtk.SpinButton.new_with_range(low,high,step);s.set_digits(1 if step<1 else 0);s.set_value(value);return s
    def activate(self):
        active=max(0,self.tool.get_active());self.tool.remove_all()
        for t,d in enumerate(store.NOZZLES):self.tool.append_text(f'T{t} - {d} mm')
        self.tool.set_active(min(active,store.tool_count()-1));self.load()
    def load(self,*args):
        if self.tool.get_active() not in range(store.tool_count()):return
        r=store.assigned(self.tool.get_active());self.run=None
        if not r:
            self.name.set_text('');self.info.set_text('Prima salva e assegna il filamento nella pagina Filamenti.');return
        self.name.set_text(r['name']);self.fan.set_value(100 if 'PLA' in r.get('type','') else 50 if 'PETG' in r.get('type','') else 0)
        d=store.NOZZLES[self.tool.get_active()];h=tests.max_flow_layer_height(d)
        ceiling=min(25,tests.area(d*1.1,h)*r.get('flow',1)*300)
        self.end.set_value(max(.3,int(ceiling*10)/10));self.start.set_value(max(.2,min(5,ceiling/3)))
        self.step.set_value(.2 if ceiling<5 else 2)
        self.choice.set_range(1,7 if self.mode=='flow' else 30)
        self.info.set_text((f"Flow attuale {r.get('flow',1):.4f}. 7 campioni: 1-4 davanti da sinistra a destra; 5-7 dietro. Scegli la superficie piu uniforme, senza solchi o rigonfiamenti." if self.mode=='flow' else
                            'Torre a portata crescente. Base di 3 strati esclusa; ogni fascia misura 1,2 mm. Scegli l’ultima fascia con pareti uniformi prima dei difetti. Si salva il 90% della portata provata.'))
    def state(self):
        with urlopen('http://127.0.0.1:7125/printer/objects/query?gcode_macro%20_INDX_SETUP&print_stats&extruder&gcode_move',timeout=3) as response:return json.load(response)['result']['status']
    def test(self,widget):
        self._screen.remove_keyboard()
        try:
            t=self.tool.get_active();r=store.assigned(t)
            if not r or not r.get('library_id'):raise ValueError('Prima salva e assegna il filamento.')
            state=self.state();setup=state.get('gcode_macro _INDX_SETUP',{})
            if not setup.get('geometry_verified') or not setup.get('cleaning_verified'):raise ValueError('Test bloccato: prima collaudare testa, dock e pulizia INDX.')
            if state.get('print_stats',{}).get('state') in ('printing','paused'):raise ValueError('Stampante occupata.')
            movement=state.get('gcode_move',{});old_pa=state.get('extruder',{}).get('pressure_advance',0)
            args=dict(tool=t,temp=r['temp'],bed=r['bed'],fan=self.fan.get_value_as_int(),old_pa=old_pa,old_flow=movement.get('extrude_factor',1),old_speed=movement.get('speed_factor',1),nozzle=store.NOZZLES[t])
            if self.mode=='flow':code,values=tests.flow_test(base=r.get('flow',1),step=.01 if self.fine.get_active() else .02,**args)
            else:code,values=tests.max_flow_test(ratio=r.get('flow',1),start=self.start.get_value(),end=self.end.get_value(),step=self.step.get_value(),**args)
            filename='INDX_'+self.mode+'_'+str(time.time_ns())+'.gcode'
            Path('/home/sovol/printer_data/gcodes',filename).write_text(code)
            self.run=dict(library_id=r['library_id'],tool=t,hardware_key=store.nozzle_key(t),values=values,filename=filename,temp=r['temp'],bed=r['bed'],flow=r.get('flow',1),generated=time.time())
            store.write_json('indx-'+self.mode+'-last-test.json',self.run)
            self.choice.set_range(1,len(values));self.choice.set_value(4 if self.mode=='flow' else 1)
            self._screen._confirm_send_action(widget,'Piano libero? Il test esegue homing, pulizia, cambio utensile e riscaldamento con i valori del profilo. Area X130-230 Y145-191. Conferma il filamento caricato.',
                'printer.gcode.script',{'script':'SDCARD_PRINT_FILE FILENAME='+filename})
            self.status.set_text('Valori dei campioni: '+', '.join(f'{i+1}: {v:.3f}' for i,v in enumerate(values)))
        except Exception as e:self.status.set_text(str(e))
    def save(self,*args):
        self._screen.remove_keyboard()
        try:
            run=self.run or store.read_json('indx-'+self.mode+'-last-test.json',{})
            t=self.tool.get_active();r=store.assigned(t)
            if not run or not r or run.get('tool')!=t or run.get('library_id')!=r.get('library_id'):raise ValueError('Non esiste un test per questo filamento e utensile.')
            if run.get('hardware_key')!=store.nozzle_key(t):raise ValueError('Ugello modificato dopo il test: ristampa il test.')
            if any(run.get(k)!=r.get(k,1 if k=='flow' else None) for k in ('temp','bed','flow')):raise ValueError('Profilo modificato dopo il test: ristampa il test.')
            stats=self.state().get('print_stats',{})
            if stats.get('state')!='complete' or stats.get('filename')!=run['filename']:raise ValueError('Il test deve risultare completato prima di salvarne il risultato.')
            i=self.choice.get_value_as_int()-1
            if not 0<=i<len(run['values']):raise ValueError('Campione non valido.')
            value=run['values'][i]*(.9 if self.mode=='max_flow' else 1)
            saved=store.save_calibration(t,self.mode,round(value,5),name=self.name.get_text(),sample=i+1,test=run)
            self.status.set_text(f"Salvato {self.mode}: {value:.4f} in {saved['name']} T{t}. Sincronizza INDX in Orca per salvare e usare il profilo.")
        except Exception as e:self.status.set_text(str(e))
