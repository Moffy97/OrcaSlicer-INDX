"""Persistent INDX user configuration. Never invents dock coordinates or moves axes."""
import ast,configparser,copy,hashlib,json,math,os,re,time,tempfile
from pathlib import Path

MAX_TOOLS=64
FIELDS=('x','dock_y','offset_x','offset_y','offset_z')
DEFAULT_PATHS={'config':'indx/indx.cfg','profile':'printer.cfg','commissioning':'indx-orca-commissioning.cfg','variables':'indx_vars.cfg'}

def path(root,name):
 p=(Path(root)/name).resolve()
 if not p.is_relative_to(Path(root).resolve()):raise ValueError('Percorso esterno alla configurazione')
 return p

def paths(root):
 f=Path(root)/'indx-machine-paths.json'
 values={**DEFAULT_PATHS,**(json.loads(f.read_text(encoding='utf-8')) if f.exists() else {})}
 return {k:path(root,values[k]) for k in DEFAULT_PATHS}

def sections(text):
 return {m[1]:m[0] for m in re.finditer(r'^\[([^\]\n]+)\][^\n]*\n.*?(?=^\[|\Z)',text,re.M|re.S)}

def literals(text):
 result={}
 for m in re.finditer(r'^variable_(\w+)\s*:\s*([^\n#]+)',text,re.M):
  try:result[m[1]]=ast.literal_eval(m[2].strip())
  except (ValueError,SyntaxError):pass
 return result

def fingerprint(root):
 ps=paths(root)
 names=[ps['config'],ps['commissioning'],ps['variables'],ps['profile'],Path(root)/'indx-tool-setup.json',Path(root)/'indx-machine-paths.json']
 return hashlib.sha256(b''.join(str(p).encode()+b'\0'+(p.read_bytes() if p.exists() else b'') for p in names)).hexdigest()

def saved_variables(root,state):
 actual=state.get('save_variables',{}).get('variables')
 if isinstance(actual,dict):return actual
 p=paths(root)['variables'];values={}
 if p.exists():
  c=configparser.RawConfigParser();c.read_string(p.read_text(encoding='utf-8'))
  section=next((s for s in c.sections() if s.lower()=='variables'),None)
  if section is None:return values
  for k,v in c.items(section):
   try:values[k]=ast.literal_eval(v)
   except (ValueError,SyntaxError):pass
 return values

def limits(root,state):
 active=state.get('configfile',{}).get('config',{})
 if all('stepper_'+a in active for a in 'xyz'):
  source=active;origin='Configurazione attiva Klipper'
 else:
  p=paths(root)['profile'];source={k:{m[1]:m[2].split('#')[0].strip() for m in re.finditer(r'^([a-z_]+)\s*:\s*([^\n]+)',v,re.M)} for k,v in sections(p.read_text(encoding='utf-8')).items()};origin='Profilo di riferimento, non attivo'
 result={}
 for a in 'xyz':
  s=source.get('stepper_'+a,{})
  if 'position_max' not in s:raise ValueError('Limiti assi non disponibili: serve il profilo fisico della macchina')
  result[a]=[float(s.get('position_min',0)),float(s['position_max'])]
 return result,origin

def load(root,state):
 ps=paths(root);text=ps['config'].read_text(encoding='utf-8');sec=sections(text)
 if 'gcode_macro TOOL_POSITIONS' not in sec:raise ValueError('TOOL_POSITIONS non trovato nel file utente INDX')
 tp=literals(sec['gcode_macro TOOL_POSITIONS']);sv=saved_variables(root,state)
 hp=Path(root)/'indx-tool-setup.json';hardware=json.loads(hp.read_text(encoding='utf-8')) if hp.exists() else {}
 count=max(int(tp.get('tool_count',0)),len(hardware.get('tools',[])))
 if not 1<=count<=MAX_TOOLS:raise ValueError('Numero tool fuori intervallo')
 hw=hardware.get('tools',[]);tools=[]
 # A previously applied revision supplies staged offsets until it has loaded once.
 applied=Path(root)/'indx-machine-applied.json';pending=json.loads(applied.read_text(encoding='utf-8')) if applied.exists() else {}
 use_pending=pending.get('revision')!=sv.get('indx_machine_revision')
 for t in range(count):
  h=hw[t] if t<len(hw) else {};old=pending.get('configuration',{}).get('tools',[])
  row={'tool':t,'diameter':h.get('diameter'),'type':h.get('type','standard'),'cht_multiplier':h.get('cht_multiplier',1.3),
       'x':tp.get(f't{t}_x'),'dock_y':tp.get(f't{t}_dock_y')}
  for axis in 'xyz':row['offset_'+axis]=old[t].get('offset_'+axis) if use_pending and t<len(old) else sv.get(f't{t}_offset_{axis}')
  tools.append(row)
 return {'schema':1,'tools':tools,'dock_dir':tp.get('dock_dir',-1),'clearance_y':tp.get('clearance_y'),
         'trigger_offset':tp.get('trigger_offset',5.),'z_hop':tp.get('z_hop',1.)},fingerprint(root)

def number(value,name,lo,hi):
 if isinstance(value,bool) or not isinstance(value,(float,int)) or not math.isfinite(value) or not lo<=value<=hi:raise ValueError(name+': valore mancante o fuori intervallo')
 return float(value)

def validate(data,bounds):
 result=copy.deepcopy(data);tools=result.get('tools')
 if not isinstance(tools,list) or not 1<=len(tools)<=MAX_TOOLS:raise ValueError('Numero tool: 1-64')
 direction=result.get('dock_dir')
 if direction not in (-1,1):raise ValueError('Direzione dock: -1 fronte, +1 retro')
 clearance=number(result.get('clearance_y'),'Corsia Y',*bounds['y'])
 trigger=number(result.get('trigger_offset'),'Distanza ingresso',.1,25)
 number(result.get('z_hop'),'Sollevamento Z',.1,50)
 for t,row in enumerate(tools):
  if row.get('tool')!=t:raise ValueError('Numerazione tool non consecutiva')
  number(row.get('diameter'),f'T{t} diametro',.1,2)
  if row.get('type') not in ('standard','cht'):raise ValueError('Tipo ugello non valido')
  number(row.get('cht_multiplier'),f'T{t} fattore CHT',1,3)
  x=number(row.get('x'),f'T{t} dock X',*bounds['x']);dy=number(row.get('dock_y'),f'T{t} dock Y',*bounds['y'])
  number(dy-direction*trigger,f'T{t} ingresso Y',*bounds['y'])
  if direction*(dy-clearance)<26-1e-6:raise ValueError(f'T{t}: corsia Y a meno di 26 mm dal dock')
  for axis in 'xyz':number(row.get('offset_'+axis),f'T{t} offset {axis.upper()}',-10,10)
  for other in tools[:t]:
   if abs(other['x']-x)<.001 and abs(other['dock_y']-dy)<.001:raise ValueError(f'T{t}: dock duplicato')
 return result

def update_variables(section,values):
 for key,value in values.items():
  line='variable_'+key+': '+str(value)
  pattern=r'^variable_'+re.escape(key)+r'\s*:[^\n]*'
  if re.search(pattern,section,re.M):section=re.sub(pattern,lambda m:line,section,flags=re.M)
  else:
   marker=re.search(r'^gcode\s*:',section,re.M)
   if not marker:raise ValueError('Sezione TOOL_POSITIONS senza gcode')
   section=section[:marker.start()]+line+'\n'+section[marker.start():]
 return section

def render_config(text,data,revision):
 sec=sections(text);old=sec.get('gcode_macro TOOL_POSITIONS')
 if not old:raise ValueError('File INDX non supportato')
 values={k:data[k] for k in ('dock_dir','clearance_y','trigger_offset','z_hop')};values.update(tool_count=len(data['tools']),docks_calibrated=False)
 for row in data['tools']:
  t=row['tool'];values[f't{t}_x']=row['x'];values[f't{t}_dock_y']=row['dock_y']
 # Removed slots remain archived in the config but are outside tool_count.
 text=text.replace(old,update_variables(old,values),1)
 for row in data['tools']:
  t=row['tool']
  if 'gcode_macro T'+str(t) not in sections(text):text+=f'\n[gcode_macro T{t}]\nvariable_active: False\ngcode: CHANGE_TOOL TOOL={t}\n'
 # Apply offsets once per revision through Klipper's own save_variables module.
 # Later official calibrations update those values and are not overwritten on reboot.
 start='# BEGIN INDX SCREEN OFFSETS';end='# END INDX SCREEN OFFSETS'
 if text.count(start)!=text.count(end) or text.count(start)>1:raise ValueError('Blocco offset gestito non valido')
 text=re.sub(re.escape(start)+r'.*?'+re.escape(end)+r'\n?', '',text,flags=re.S)
 lines=[start,'[delayed_gcode _INDX_SCREEN_APPLY_OFFSETS]','initial_duration: 1.0','gcode:',
        "    {% if 'save_variables' in printer %}",f"        {{% if printer.save_variables.variables.indx_machine_revision|default('') != '{revision}' %}}"]
 for row in data['tools']:
  for a in 'xyz':lines.append(f"            SAVE_VARIABLE VARIABLE=t{row['tool']}_offset_{a} VALUE={row['offset_'+a]:.6f}")
 lines += [f'''            SAVE_VARIABLE VARIABLE=indx_machine_revision VALUE='"{revision}"' ''','        {% endif %}','    {% endif %}',end]
 return text.rstrip()+'\n\n'+'\n'.join(lines)+'\n'

def gate_off(text):
 text=re.sub(r'^(variable_(?:geometry_verified|cleaning_verified)\s*:)\s*[^\n]+',r'\1 False',text,flags=re.M)
 # Migrate this integration's former four-tool checks without changing moves.
 text=text.replace('for t in range(4)', 'for t in range(tp.tool_count|int)')
 text=text.replace('tool < 0 or tool > 3', "tool < 0 or tool >= (printer['gcode_macro TOOL_POSITIONS'].tool_count|int)")
 return text.replace('Utensile non valido: usare T0-T3.', 'Utensile non valido: verificare il numero tool configurato.')

def apply(root,data,expected,state,send):
 """All file changes backed up. Caller supplies a fresh local Moonraker snapshot."""
 root=Path(root)
 if state.get('print_stats',{}).get('state') not in ('standby','complete','cancelled','error'):raise ValueError('Stampante occupata o stato non disponibile')
 if state.get('idle_timeout',{}).get('state')=='Printing':raise ValueError('Macro o movimento in corso')
 for heater in ('extruder','heater_bed'):
  if state.get(heater,{}).get('target',0)>0:raise ValueError('Spegnere i riscaldatori prima di cambiare la geometria')
 bounds,_=limits(root,state);data=validate(data,bounds)
 if expected!=fingerprint(root):raise ValueError('Configurazione modificata nel frattempo: ricaricare prima di salvare')
 ps=paths(root);revision=hashlib.sha256((json.dumps(data,sort_keys=True)+str(time.time_ns())).encode()).hexdigest()[:24]
 files={ps['config']:render_config(ps['config'].read_text(encoding='utf-8'),data,revision),
        root/'indx-tool-setup.json':json.dumps({'schema':2,'confirmed_at':time.time(),'tools':[{k:r[k] for k in ('tool','diameter','type','cht_multiplier')} for r in data['tools']]},indent=2),
        root/'indx-machine-applied.json':json.dumps({'schema':1,'revision':revision,'configuration':data,'updated':time.time()},indent=2),
        root/'indx-commissioning.json':json.dumps({'schema':1,'steps':{}},indent=2)}
 if ps['commissioning'].exists():files[ps['commissioning']]=gate_off(ps['commissioning'].read_text(encoding='utf-8'))
 commands=[]
 for macro,var in [('TOOL_POSITIONS','docks_calibrated'),('_INDX_SETUP','geometry_verified'),('_INDX_SETUP','cleaning_verified')]:
  if var in state.get('gcode_macro '+macro,{}):commands.append(f'SET_GCODE_VARIABLE MACRO={macro} VARIABLE={var} VALUE=False')
 if commands:send('\n'.join(commands))
 backup=Path(tempfile.mkdtemp(prefix='indx-machine-backup-',dir=root))
 originals={p:p.read_bytes() if p.exists() else None for p in files}
 for p,content in originals.items():
  if content is not None:
   target=backup/p.relative_to(root);target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(content)
 (backup/'manifest.json').write_text(json.dumps({'files':[str(p.relative_to(root)) for p in files],'revision':revision},indent=2))
 try:
  for p,content in files.items():
   tmp=p.with_name(p.name+'.indx-tmp');tmp.write_text(content,encoding='utf-8');os.replace(tmp,p)
 except Exception:
  for p,old in originals.items():
   if old is None:p.unlink(missing_ok=True)
   else:p.write_bytes(old)
  raise
 return revision,str(backup)

def applied_status(root,state):
 p=Path(root)/'indx-machine-applied.json'
 if not p.exists():return 'Nessuna configurazione applicata da questo pannello'
 expected=json.loads(p.read_text(encoding='utf-8'));revision=expected['revision'];tp=state.get('gcode_macro TOOL_POSITIONS',{})
 sv=state.get('save_variables',{}).get('variables',{})
 if sv.get('indx_machine_revision')!=revision:return 'Salvato su disco; non caricato nelle macro INDX. Riavvio Klipper richiesto nel profilo INDX.'
 if tp.get('tool_count')!=len(expected['configuration']['tools']):return 'Numero tool nelle macro diverso dal salvataggio'
 return 'Configurazione caricata; collaudo fisico richiesto prima di abilitare i dock'

def confirm_commissioning(root,state,token,send,complete=False):
 """Explicit operator attestation only; never called by install or auto-sync."""
 root=Path(root)
 if token!=fingerprint(root):raise ValueError('Ricaricare: configurazione cambiata')
 if state.get('print_stats',{}).get('state') not in ('standby','complete','cancelled','error') or state.get('idle_timeout',{}).get('state')=='Printing':raise ValueError('Stampante occupata')
 if any(state.get(h,{}).get('target',0)>0 for h in ('extruder','heater_bed')):raise ValueError('Spegnere i riscaldatori')
 config=state.get('configfile',{}).get('config',{})
 if 'mcu indxmcu' not in config or 'load_cell_probe' not in config:raise ValueError('Serve il profilo INDX attivo con testa e cella, non il profilo manutenzione')
 p=root/'indx-machine-applied.json'
 if not p.exists():raise ValueError('Prima salvare la configurazione dal pannello Tool')
 applied=json.loads(p.read_text(encoding='utf-8'));data=applied['configuration'];sv=state.get('save_variables',{}).get('variables',{})
 if sv.get('indx_machine_revision')!=applied['revision']:raise ValueError('Configurazione non caricata: riavviare Klipper nel profilo INDX')
 bounds,_=limits(root,state);validate(data,bounds);tp=state.get('gcode_macro TOOL_POSITIONS',{})
 expected={k:data[k] for k in ('dock_dir','clearance_y','trigger_offset','z_hop')};expected['tool_count']=len(data['tools'])
 for row in data['tools']:
  for k in ('x','dock_y'):expected[f"t{row['tool']}_{k}"]=row[k]
 for k,value in expected.items():
  if not isinstance(tp.get(k),(int,float)) or abs(tp[k]-value)>.00001:raise ValueError('Macro e configurazione salvata non corrispondono: '+k)
 ps=paths(root);changes={ps['config']:update_variables(ps['config'].read_text(encoding='utf-8'),{'docks_calibrated':True})}
 commands=['SET_GCODE_VARIABLE MACRO=TOOL_POSITIONS VARIABLE=docks_calibrated VALUE=True']
 if complete:
  from panels import indx_commissioning as guide
  hw=json.loads((root/'indx-tool-setup.json').read_text(encoding='utf-8'));saved=json.loads((root/'indx-commissioning.json').read_text(encoding='utf-8'))
  checklist=guide.checklist(saved,hw)
  if any(not checklist['steps'].get(k,{}).get('done') for k,_,_ in guide.STEPS[:-1]):raise ValueError('Completare i primi sei passaggi fisici della scheda Stato')
  setup=state.get('gcode_macro _INDX_SETUP',{})
  if not all(k in setup for k in ('geometry_verified','cleaning_verified')) or not ps['commissioning'].exists():raise ValueError('Macro di collaudo di questa integrazione non disponibili')
  text=gate_off(ps['commissioning'].read_text(encoding='utf-8'))
  text=re.sub(r'^(variable_(?:geometry_verified|cleaning_verified)\s*:)\s*False',r'\1 True',text,flags=re.M);changes[ps['commissioning']]=text
  commands += ['SET_GCODE_VARIABLE MACRO=_INDX_SETUP VARIABLE=geometry_verified VALUE=True','SET_GCODE_VARIABLE MACRO=_INDX_SETUP VARIABLE=cleaning_verified VALUE=True']
 backup=root/('indx-machine-backup-'+str(time.time_ns()));backup.mkdir()
 old={p:p.read_bytes() for p in changes}
 for p,content in old.items():
  dest=backup/p.relative_to(root);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(content)
 try:
  for p,text in changes.items():
   tmp=p.with_name(p.name+'.indx-tmp');tmp.write_text(text,encoding='utf-8');os.replace(tmp,p)
  send('\n'.join(commands))
 except Exception:
  for p,content in old.items():p.write_bytes(content)
  # If the response was lost, restore restrictive runtime gates as well.
  try:send('\n'.join(c.replace('VALUE=True','VALUE=False') for c in commands))
  except Exception:pass
  raise
 return 'Collaudo dichiarato dall\'operatore; stampa di prova ancora da verificare' if complete else 'Dock dichiarati misurati: test controllati abilitati, stampa ancora bloccata dal collaudo'
