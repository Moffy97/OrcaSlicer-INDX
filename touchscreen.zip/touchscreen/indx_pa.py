"""INDX PA: local, visually evaluated calibration. No load-cell inference."""
import json, math, re, os, time
from pathlib import Path
from urllib.request import urlopen
import gi
gi.require_version('Gtk', '3.0')
from gi.repository import Gtk
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store
CONFIG = Path('/home/sovol/printer_data/config')

def make_test(tool, temp, bed, start, step, old_pa, flow=1, nozzle=None):
    nozzle = store.NOZZLES[tool] if nozzle is None else nozzle
    width, height = nozzle * 1.05, min(.2,nozzle/2)
    area = height * (width-height) + math.pi * (height/2)**2
    e_per_mm = area*flow/(math.pi*(1.75/2)**2)
    fast = min(60, 8/(area*flow))
    lines = ['; INDX PA: 11 righe dal davanti verso il retro, PA=start+indice*passo',
             '_INDX_REQUIRE_COMMISSIONED', f'INDX_PRINT_START TOOL={tool} EXTRUDER={temp} BED={bed}',
             'G90', 'M83', 'G92 E0', 'M107', 'SET_PRESSURE_ADVANCE ADVANCE=0',
             'G1 Z5 F600', 'G1 X150 Y140 F3000', f'G1 Z{height:.3f} F600',
             f'G1 X250 E{100*e_per_mm:.5f} F1200']
    for i in range(11):
        lines += [f'; RIGA {i+1}: PA {start+i*step:.4f}', 'G1 E-0.5 F1800',
                  'G1 Z0.6 F600', f'G1 X150 Y{150+6*i} F3000',
                  f'G1 Z{height:.3f} F600', 'G1 E0.5 F1800', f'SET_PRESSURE_ADVANCE ADVANCE={start+i*step:.4f}']
        for x,length,speed in [(170,20,20),(230,60,fast),(250,20,20)]:
            lines.append(f'G1 X{x} E{length*e_per_mm:.5f} F{speed*60:.1f}')
    lines += ['G1 E-0.5 F1800','G1 Z5 F600',f'SET_PRESSURE_ADVANCE ADVANCE={old_pa:.5f}',
              'INDX_PRINT_END', 'RESPOND MSG="PA: scegli la riga piu uniforme. Riga 1 davanti, riga 11 dietro. Il valore non e stato scelto automaticamente."']
    return '\n'.join(lines)+'\n'

class Panel(ScreenPanel):
    def __init__(self, screen, title, tool=0):
        super().__init__(screen, title or 'Calibra PA INDX')
        self.bases = json.loads((CONFIG/'indx-pa-bases.json').read_text())
        self.grid = Gtk.Grid(column_spacing=12,row_spacing=7)
        self.tool = Gtk.ComboBoxText()
        for t,d in enumerate(store.NOZZLES): self.tool.append_text(f'T{t} - {d} mm {store.hardware(t)["type"]}')
        self.tool.set_active(tool)
        self.base = Gtk.ComboBoxText()
        for key in self.bases: self.base.append_text(key)
        self.base.set_active(0)
        self.name = Gtk.Entry(placeholder_text='Marca, materiale e colore',hexpand=True)
        self.name.connect('focus-in-event', self._screen.show_keyboard)
        self.temp = self.spin(170,340,1,210,0)
        self.bed = self.spin(0,110,1,60,0)
        self.start = self.spin(0,0.9,0.005,0,3)
        self.step = self.spin(0.001,0.05,0.001,0.01,3)
        self.row = self.spin(1,11,1,1,0)
        self.value = self.spin(0,1,0.001,0,3)
        for n,(label,widget) in enumerate([('Utensile',self.tool),('Base materiale',self.base),('Nome filamento',self.name),('Ugello C',self.temp),('Piano C',self.bed),('PA iniziale',self.start),('Passo PA',self.step),('Riga migliore (1 davanti)',self.row),('PA da salvare',self.value)]):
            self.grid.attach(Gtk.Label(label=label,halign=Gtk.Align.START),0,n,1,1)
            self.grid.attach(widget,1,n,1,1)
        self.base.connect('changed',self.change_base)
        for w in (self.start,self.step,self.row): w.connect('value-changed',self.choose_row)
        self.status=Gtk.Label(label='Valutazione visiva: 11 righe. Nessuna misura PA tramite cella.',wrap=True)
        self.grid.attach(self.status,0,9,2,1)
        for col,(label,callback) in enumerate([('Stampa test PA',self.test),('Salva PA per Orca',self.save)]):
            b=self._gtk.Button(label=label); b.connect('clicked',callback); self.grid.attach(b,col,10,1,1)
        scroll=Gtk.ScrolledWindow();scroll.add(self.grid);self.content.add(scroll)
        self.tool.connect('changed',self.load_assigned)
        self.load_assigned()
    def load_assigned(self,*args):
        if self.tool.get_active() not in range(store.tool_count()):return
        p=CONFIG/'indx-filament-assignments.json'
        a=json.loads(p.read_text()) if p.exists() else {}
        t=self.tool.get_active();r=store.assigned(t)
        if not r:
            self.name.set_text('');self.value.set_value(0)
            self.status.set_text('Prima assegna marca e prodotto in INDX > Filamenti per testa, oppure inserisci il nome qui.')
            return
        if r['base'].startswith('orca:'):
            profile=next((x for x in store.catalog()['profiles'] if x['id']==r.get('profile_id')),None)
            if not profile:
                self.status.set_text('Profilo non disponibile: sincronizza i profili da Orca e riassegna il filamento.')
                self.name.set_text('');return
            if r['base'] not in self.bases:
                self.bases[r['base']]={'profile':profile['config'],'temp':r['temp'],'bed':r['bed']}
                self.base.append_text(r['base'])
            self.name.set_editable(True);self.base.set_sensitive(False)
        self.base.set_active(list(self.bases).index(r['base']))
        self.name.set_text(r['name']);self.temp.set_value(r['temp']);self.bed.set_value(r['bed'])
        p=CONFIG/'indx-pa-results.json';results=json.loads(p.read_text()) if p.exists() else {}
        saved=results.get(r['name']+'|T'+str(t),{})
        calibrated=store.resolve_pa(r,t,results);valid=calibrated is not None
        profile_config=self.bases[r['base']]['profile']
        source_pa=store.number(profile_config,'pressure_advance',0) if str(store.first(profile_config,'enable_pressure_advance','0'))=='1' else 0
        self.value.set_value(calibrated if valid else source_pa)
        self.status.set_text(r['name']+(' - PA INDX salvato: '+str(calibrated) if valid else ' - PA del profilo: '+str(source_pa)+'; PA INDX da calibrare'))
    def activate(self):
        active=max(0,self.tool.get_active());self.tool.remove_all()
        for t,d in enumerate(store.NOZZLES):self.tool.append_text(f'T{t} - {d} mm')
        self.tool.set_active(min(active,store.tool_count()-1));self.load_assigned()
    def spin(self,low,high,step,value,digits):
        w=Gtk.SpinButton.new_with_range(low,high,step);w.set_digits(digits);w.set_value(value);return w
    def change_base(self,*args):
        b=self.bases[self.base.get_active_text()];self.temp.set_value(b['temp']);self.bed.set_value(b['bed'])
    def choose_row(self,*args):
        self.value.set_value(self.start.get_value()+(self.row.get_value_as_int()-1)*self.step.get_value())
    def data(self):
        name=self.name.get_text().strip()
        if not 2<=len(name)<=160 or any(ord(c)<32 for c in name):
            raise ValueError('Nome filamento: 2-160 caratteri senza caratteri di controllo.')
        t=self.tool.get_active()
        d=dict(name=name,tool=t,nozzle=store.NOZZLES[t],nozzle_type=store.hardware(t)['type'],base=self.base.get_active_text(),
                    temp=self.temp.get_value_as_int(),bed=self.bed.get_value_as_int(),pa=round(self.value.get_value(),4))
        assigned=store.read_json('indx-filament-assignments.json',{}).get(str(t),{})
        if assigned.get('name')==name and assigned.get('base')==d['base']:
            for key in ['profile_id','profile_revision']:d[key]=assigned.get(key,'')
        return d
    def test(self,widget):
        self._screen.remove_keyboard()
        try:
            d=self.data();start=self.start.get_value();step=self.step.get_value()
            if start+10*step>1: raise ValueError('Intervallo PA troppo alto: ultimo valore massimo 1.')
            with urlopen('http://127.0.0.1:7125/printer/objects/query?gcode_macro%20_INDX_SETUP&print_stats&extruder',timeout=3) as r:
                state=json.load(r)['result']['status']
            setup=state.get('gcode_macro _INDX_SETUP',{})
            if not setup.get('geometry_verified') or not setup.get('cleaning_verified'):
                raise ValueError('Test bloccato: prima collaudare testa, dock e pulizia INDX.')
            if state.get('print_stats',{}).get('state') in ('printing','paused'): raise ValueError('Stampante occupata.')
            old=state.get('extruder',{}).get('pressure_advance',0)
            assigned=store.assigned(d['tool']) or {}
            if not assigned.get('library_id'):raise ValueError('Prima salva e assegna un filamento personale.')
            text=make_test(d['tool'],d['temp'],d['bed'],start,step,old,flow=assigned.get('flow',1))
            filename='INDX_PA_'+str(time.time_ns())+'.gcode'
            Path('/home/sovol/printer_data/gcodes',filename).write_text(text)
            run=dict(library_id=assigned['library_id'],tool=d['tool'],hardware_key=store.nozzle_key(d['tool']),filename=filename,temp=d['temp'],bed=d['bed'],flow=assigned.get('flow',1),start=start,step=step)
            store.write_json('indx-pa-last-test.json',run)
            self._screen._confirm_send_action(widget,
                'Piano libero? Stampa 11 righe nella zona X150-250 Y140-210, con homing, pulizia e cambi utensile. Conferma temperature e filamento.',
                'printer.gcode.script', {'script':'SDCARD_PRINT_FILE FILENAME='+filename})
            self.status.set_text('Riga 1 davanti, riga 11 dietro. Scegli la riga piu uniforme nei cambi di velocita.')
        except Exception as e: self.status.set_text(str(e))
    def save(self,widget):
        self._screen.remove_keyboard()
        try:
            d=self.data();d['updated']=time.time();d['method']='visual-manual'
            assigned=store.assigned(d['tool'])
            if assigned and assigned.get('library_id'):
                run=store.read_json('indx-pa-last-test.json',{})
                if run.get('library_id')!=assigned['library_id'] or run.get('tool')!=d['tool'] or run.get('hardware_key')!=store.nozzle_key(d['tool']):raise ValueError('Serve un test PA per questo filamento e ugello.')
                if any(run.get(k)!=assigned.get(k) for k in ('temp','bed','flow')) or any(d[k]!=run.get(k) for k in ('temp','bed')):raise ValueError('Condizioni cambiate dopo il test PA: ristampa il test.')
                with urlopen('http://127.0.0.1:7125/printer/objects/query?print_stats',timeout=3) as response:stats=json.load(response)['result']['status']['print_stats']
                if stats.get('state')!='complete' or stats.get('filename')!=run.get('filename'):raise ValueError('Il test PA deve risultare completato prima di salvare.')
                store.save_calibration(d['tool'],'pa',d['pa'],name=d['name'],sample=self.row.get_value_as_int(),test=run)
                self.status.set_text(f"PA {d['pa']:.4f} salvato in {d['name']} T{d['tool']}. Profilo rinominabile e richiamabile: sincronizza INDX in Orca.")
                return
            p=CONFIG/'indx-pa-results.json'
            records=json.loads(p.read_text()) if p.exists() else {}
            key=d['name']+'|T'+str(d['tool'])
            records[key]=d
            tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(records,indent=2));os.replace(tmp,p)
            self.status.set_text(f"Salvato PA {d['pa']:.3f} per {d['name']} T{d['tool']}. Premi INDX in Orca personalizzato per richiamarlo nel progetto. Non applicato alla stampa corrente.")
        except Exception as e:self.status.set_text(str(e))
