"""Touchscreen editor for the INDX user file, nozzle hardware and saved offsets."""
import copy,json,threading
from urllib.request import urlopen,Request
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,GLib
from ks_includes.screen_panel import ScreenPanel
from panels import indx_profiles as store
from panels import indx_machine as machine

QUERY='configfile&save_variables&gcode_macro%20TOOL_POSITIONS&gcode_macro%20_INDX_SETUP&print_stats&idle_timeout&toolhead&extruder&heater_bed'
def request(route,payload=None):
 data=None if payload is None else json.dumps(payload).encode()
 req=Request('http://127.0.0.1:7125'+route,data=data,headers={'Content-Type':'application/json'})
 with urlopen(req,timeout=8) as response:result=json.load(response)
 if 'error' in result:raise ValueError(str(result['error']))
 return result.get('result',{})

class Panel(ScreenPanel):
 def __init__(self,screen,title):
  super().__init__(screen,title or 'Dock e offset INDX');self.data=None;self.token=None;self.index=None;self.loading=False;self.busy=False
  grid=Gtk.Grid(column_spacing=10,row_spacing=8,margin=10);self.widgets={}
  self.status=Gtk.Label(label='Carica la configurazione per iniziare. Nessun movimento automatico.',wrap=True,halign=Gtk.Align.START);grid.attach(self.status,0,0,2,1)
  self.count=Gtk.SpinButton.new_with_range(1,64,1);self.count.set_size_request(120,42);grid.attach(Gtk.Label(label='Numero tool'),0,1,1,1);grid.attach(self.count,1,1,1,1)
  self.cards=Gtk.FlowBox();self.cards.set_selection_mode(Gtk.SelectionMode.NONE);self.cards.set_max_children_per_line(4);self.cards.set_min_children_per_line(2)
  card_scroll=Gtk.ScrolledWindow();card_scroll.set_min_content_height(115);card_scroll.add(self.cards);grid.attach(card_scroll,0,2,2,1)
  for row,(key,label) in enumerate([('diameter','Diametro ugello mm'),('cht_multiplier','Fattore CHT stimato'),('x','Dock X macchina mm'),('dock_y','Dock Y completamente inserito mm'),('offset_x','Offset X tool mm'),('offset_y','Offset Y tool mm'),('offset_z','Offset Z tool mm')],3):
   e=Gtk.Entry();e.connect('focus-in-event',self._screen.show_keyboard);self.widgets[key]=e;grid.attach(Gtk.Label(label=label,halign=Gtk.Align.START),0,row,1,1);grid.attach(e,1,row,1,1)
  self.kind=Gtk.Switch();grid.attach(Gtk.Label(label='Ugello CHT (spento = Standard)'),0,10,1,1);grid.attach(self.kind,1,10,1,1)
  self.direction=Gtk.Switch();grid.attach(Gtk.Label(label='Dock sul retro +Y (spento = fronte -Y)'),0,11,1,1);grid.attach(self.direction,1,11,1,1)
  for row,(key,label) in enumerate([('clearance_y','Corsia libera Y mm'),('trigger_offset','Distanza ingresso mm'),('z_hop','Sollevamento cambio tool mm')],12):
   e=Gtk.Entry();e.connect('focus-in-event',self._screen.show_keyboard);self.widgets[key]=e;grid.attach(Gtk.Label(label=label,halign=Gtk.Align.START),0,row,1,1);grid.attach(e,1,row,1,1)
  self.buttons=[]
  for row,(label,callback) in enumerate([('Ricarica da configurazione / macro',self.reload),('Riprendi bozza salvata',self.restore_draft),('Leggi posizione attuale per il dock',self.capture),('Salva bozza senza applicare',self.draft),('Verifica e salva configurazione',self.apply),('Riavvia Klipper per caricare',self.restart)],15):
   b=self._gtk.Button(label=label);b.connect('clicked',callback);grid.attach(b,0,row,2,1);self.buttons.append(b)
  self.attest=Gtk.CheckButton(label='Confermo di avere eseguito le verifiche fisiche richieste');grid.attach(self.attest,0,21,2,1)
  for row,(label,callback) in enumerate([('Conferma dock misurati: abilita test',self.confirm_docks),('Test aggancio tool selezionato',self.pickup),('Parcheggia tool attivo',self.park),('Conferma collaudo per la stampa',self.confirm_all)],22):
   b=self._gtk.Button(label=label);b.connect('clicked',callback);grid.attach(b,0,row,2,1);self.buttons.append(b)
  grid.attach(Gtk.Label(label='Quote nuove vuote: inserire misure reali. Offset = valori Klipper, non correzioni dello slicer.\nSalvare non muove gli assi. Il caricamento richiede un riavvio; dock e collaudo restano disabilitati dopo una modifica.',wrap=True),0,26,2,1)
  scroll=Gtk.ScrolledWindow();scroll.add(grid);self.content.pack_start(scroll,True,True,0)
  self.count.connect('value-changed',self.resize)

 def activate(self):
  if self.data is None:self.reload()

 def run(self,work,done):
  if self.busy:return
  self.busy=True
  for b in self.buttons:b.set_sensitive(False)
  def worker():
   try:value=work();error=None
   except Exception as e:value=None;error=str(e)
   GLib.idle_add(finish,value,error)
  def finish(value,error):
   self.busy=False
   for b in self.buttons:b.set_sensitive(True)
   if error:self.status.set_text(error)
   else:done(value)
   return False
  threading.Thread(target=worker,daemon=True).start()

 def reload(self,*args):
  def work():
   state=request('/printer/objects/query?'+QUERY)['status'];data,token=machine.load(store.CONFIG,state)
   bounds,origin=machine.limits(store.CONFIG,state)
   return data,token,machine.applied_status(store.CONFIG,state)+'\n'+origin+': '+str(bounds)
  def done(value):self.data,self.token,message=value;self.display();self.status.set_text(message)
  self.run(work,done)

 def display(self):
  self.loading=True;self.count.set_value(len(self.data['tools']))
  for child in self.cards.get_children():self.cards.remove(child)
  for row in self.data['tools']:
   label=f"T{row['tool']}\n{row.get('diameter') or '?'} mm {row.get('type','standard').upper()}"
   button=Gtk.Button(label=label);button.set_size_request(115,58);button.connect('clicked',self.select,row['tool']);self.cards.add(button)
  self.cards.show_all();self.direction.set_active(self.data['dock_dir']==1)
  for k in ('clearance_y','trigger_offset','z_hop'):self.widgets[k].set_text('' if self.data.get(k) is None else str(self.data[k]))
  self.index=None;self.loading=False;self.select(None,0)

 def commit_row(self):
  if self.data is None or self.index is None:return
  row=self.data['tools'][self.index]
  for key in ('diameter','cht_multiplier')+machine.FIELDS:
   text=self.widgets[key].get_text().strip().replace(',','.')
   if text:
    try:row[key]=float(text)
    except ValueError:raise ValueError(key+': inserire un numero')
   else:row[key]=None
  row['type']='cht' if self.kind.get_active() else 'standard'

 def gather(self):
  self.commit_row()
  if self.data is None:raise ValueError('Caricare prima la configurazione')
  for key in ('clearance_y','trigger_offset','z_hop'):
   text=self.widgets[key].get_text().strip().replace(',','.');self.data[key]=float(text) if text else None
  self.data['dock_dir']=1 if self.direction.get_active() else -1
  return copy.deepcopy(self.data)

 def select(self,widget,t):
  if self.loading or self.data is None:return
  try:self.commit_row()
  except ValueError as e:self.status.set_text(str(e));return
  if t<0:return
  self.index=t;row=self.data['tools'][t]
  if hasattr(self._screen,'dashboard'):self._screen.dashboard.selected_tool=t
  for key in ('diameter','cht_multiplier')+machine.FIELDS:self.widgets[key].set_text('' if row.get(key) is None else str(row[key]))
  self.kind.set_active(row.get('type','standard')=='cht')
  for index,child in enumerate(self.cards.get_children()):
   context=child.get_child().get_style_context()
   context.add_class('suggested-action') if index==t else context.remove_class('suggested-action')

 def resize(self,*args):
  if self.loading or self.data is None:return
  try:
   self.gather();count=self.count.get_value_as_int();old=self.data['tools']
   self.data['tools']=old[:count]+[dict(tool=t,diameter=.4,type='standard',cht_multiplier=1.3,**{k:None for k in machine.FIELDS}) for t in range(len(old),count)]
   self.display();self.status.set_text('Numero aggiornato nella bozza. Completare le quote dei nuovi tool prima di applicare.')
  except Exception as e:self.status.set_text(str(e))

 def draft(self,*args):
  try:store.write_json('indx-machine-draft.json',self.gather());self.status.set_text('Bozza salvata. Nessuna modifica al firmware o al montaggio pubblicato.')
  except Exception as e:self.status.set_text(str(e))

 def restore_draft(self,*args):
  try:
   value=store.read_json('indx-machine-draft.json',{})
   if value.get('schema')!=1 or not isinstance(value.get('tools'),list) or not 1<=len(value['tools'])<=64:raise ValueError('Nessuna bozza valida')
   self.data=value;self.display();self.status.set_text('Bozza ripresa. Verificare e salvare per applicarla.')
  except Exception as e:self.status.set_text(str(e))

 def capture(self,*args):
  if self.index is None:return
  selected=self.index
  def work():
   state=request('/printer/objects/query?toolhead&print_stats&idle_timeout')['status'];th=state.get('toolhead',{})
   if state.get('print_stats',{}).get('state') in ('printing','paused') or state.get('idle_timeout',{}).get('state')=='Printing':raise ValueError('Attendere la fine dei movimenti')
   if not all(a in th.get('homed_axes','') for a in 'xy'):raise ValueError('Lettura dock: servono X/Y referenziati; nessun homing avviato dal pannello')
   return th['position'][:2]
  def done(pos):
   if self.index!=selected:self.status.set_text('Tool cambiato durante la lettura: ripetere');return
   self.widgets['x'].set_text(str(pos[0]));self.widgets['dock_y'].set_text(str(pos[1]));self.status.set_text('Posizione letta, non ancora salvata. Verificare che sia il dock completamente inserito.')
  self.run(work,done)

 def apply(self,*args):
  self._screen.remove_keyboard()
  try:data=self.gather();token=self.token
  except Exception as e:self.status.set_text(str(e));return
  def work():
   state=request('/printer/objects/query?'+QUERY)['status']
   return machine.apply(store.CONFIG,data,token,state,lambda script:request('/printer/gcode/script',{'script':script}))
  def done(value):self.token=machine.fingerprint(store.CONFIG);self.status.set_text('Configurazione salvata con backup. '+value[1]+'\nRiavvio Klipper richiesto nel profilo INDX. Nessun movimento eseguito; dock e collaudo disabilitati.')
  self.run(work,done)

 def restart(self,*args):
  def work():
   state=request('/printer/objects/query?print_stats&idle_timeout&extruder&heater_bed')['status']
   if state.get('print_stats',{}).get('state') not in ('standby','complete','cancelled','error') or state.get('idle_timeout',{}).get('state')=='Printing':raise ValueError('Stampante occupata: riavvio non eseguito')
   if any(state.get(h,{}).get('target',0)>0 for h in ('extruder','heater_bed')):raise ValueError('Spegnere i riscaldatori prima del riavvio')
   request('/printer/restart',{});return 'Riavvio Klipper richiesto. Ricaricare lo stato dopo la connessione; il profilo manutenzione non attiva INDX.'
  self.run(work,lambda message:self.status.set_text(message))

 def confirm(self,complete):
  if not self.attest.get_active():self.status.set_text('Confermare prima le verifiche fisiche. Non e una misura automatica.');return
  def work():
   state=request('/printer/objects/query?'+QUERY)['status']
   return machine.confirm_commissioning(store.CONFIG,state,self.token,lambda script:request('/printer/gcode/script',{'script':script}),complete)
  def done(message):self.token=machine.fingerprint(store.CONFIG);self.attest.set_active(False);self.status.set_text(message)
  self.run(work,done)
 def confirm_docks(self,*args):self.confirm(False)
 def confirm_all(self,*args):self.confirm(True)
 def motion(self,widget,park=False):
  try:
   state=request('/printer/objects/query?'+QUERY)['status'];tp=state.get('gcode_macro TOOL_POSITIONS',{})
   if not tp.get('docks_calibrated') or 'Configurazione caricata' not in machine.applied_status(store.CONFIG,state):raise ValueError('Caricare la configurazione e confermare prima tutti i dock misurati')
   if state.get('print_stats',{}).get('state') in ('printing','paused') or state.get('idle_timeout',{}).get('state')=='Printing':raise ValueError('Stampante occupata')
   command='PARK_TOOL' if park else 'CHANGE_TOOL TOOL='+str(self.index)
   if not park and self.index is None:raise ValueError('Selezionare un tool')
   self._screen._confirm_send_action(widget,'Test fisico con movimento: area libera, tool e dock verificati, arresto di emergenza accessibile.', 'printer.gcode.script',{'script':command})
  except Exception as e:self.status.set_text(str(e))
 def pickup(self,widget):self.motion(widget)
 def park(self,widget):self.motion(widget,True)
