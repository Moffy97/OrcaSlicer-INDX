"""Shared GTK layout primitives for the INDX touch interface."""
import gi
gi.require_version('Gtk','3.0')
from gi.repository import Gtk,Pango

def style(widget,*names):
 for name in names:widget.get_style_context().add_class(name)
 return widget

def label(text,kind=None):
 w=Gtk.Label(label=text,halign=Gtk.Align.START,xalign=0,wrap=True);w.set_max_width_chars(42)
 if kind:style(w,kind)
 return w

def card(title,subtitle=None):
 box=style(Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=10),'indx-card')
 box.pack_start(label(title,'indx-section'),False,False,0)
 if subtitle:box.pack_start(label(subtitle,'indx-muted'),False,False,0)
 return box

def field(box,title,widget):
 if isinstance(widget,Gtk.ComboBox):
  for cell in widget.get_cells():
   if isinstance(cell,Gtk.CellRendererText):cell.set_property('ellipsize',Pango.EllipsizeMode.END);cell.set_property('max-width-chars',27)
 row=Gtk.Box(orientation=Gtk.Orientation.VERTICAL,spacing=4)
 row.pack_start(label(title,'indx-field-label'),False,False,0)
 widget.set_hexpand(True);row.pack_start(widget,False,False,0);box.pack_start(row,False,False,0)

def button(text,callback,*args,primary=False):
 w=Gtk.Button(label=text);w.set_size_request(-1,48);w.connect('clicked',callback,*args)
 w.get_child().set_line_wrap(True);w.get_child().set_max_width_chars(28)
 if primary:style(w,'indx-primary')
 return w

def columns(*boxes):
 grid=Gtk.Grid(column_homogeneous=True,column_spacing=14,row_spacing=14)
 for i,box in enumerate(boxes):grid.attach(box,i%2,i//2,1,1)
 return grid

def scroll(content):
 w=Gtk.ScrolledWindow();w.set_policy(Gtk.PolicyType.NEVER,Gtk.PolicyType.AUTOMATIC);w.add(content)
 return w

def prepare(widget):
 """Bound intrinsic widths so long profile names don't expand the screen."""
 if isinstance(widget,Gtk.Label):widget.set_line_wrap(True);widget.set_max_width_chars(32)
 if isinstance(widget,Gtk.Button):widget.set_vexpand(False)
 if isinstance(widget,Gtk.Entry):widget.set_width_chars(12)
 if isinstance(widget,Gtk.ComboBox):
  for cell in widget.get_cells():
   if isinstance(cell,Gtk.CellRendererText):cell.set_property('ellipsize',Pango.EllipsizeMode.END);cell.set_property('max-width-chars',24)
 if isinstance(widget,Gtk.Container):
  for child in widget.get_children():prepare(child)
