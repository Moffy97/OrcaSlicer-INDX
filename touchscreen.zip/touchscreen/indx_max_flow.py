from panels.indx_flow import Panel as FlowPanel

class Panel(FlowPanel):
    def __init__(self,screen,title,tool=0):
        super().__init__(screen,title or 'Calibra flusso massimo',tool=tool,mode='max_flow')
