"""Orca-to-touch metadata consumer. No G-code or heater/motion API is used."""
import copy,json,re,time,logging
from urllib.request import urlopen
try:from panels import indx_profiles as store
except ImportError:import indx_profiles as store

REQUEST='indx-orca-sync-request.json'
ACK='indx-orca-sync-ack.json'

def apply_request(request):
    """Validate the entire batch against its observed base before committing it."""
    with store.transaction():
        ident=request.get('request_id')
        if not isinstance(ident,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{8,80}',ident):raise ValueError('Identita richiesta non valida')
        old=store.read_json(ACK,{})
        if old.get('request_id')==ident and old.get('status') in ('applied','conflict','error'):return old
        try:
            if request.get('schema')!=1:raise ValueError('Protocollo sincronizzazione non supportato')
            changes=request.get('changes')
            if not isinstance(changes,list) or not 1<=len(changes)<=store.MAX_TOOLS:raise ValueError('Elenco modifiche non valido')
            records=store.library();assignments=store.read_json('indx-filament-assignments.json',{});seen=set();updates=[]
            incoming=store.CONFIG/'indx-orca-catalog.json.z'
            catalog=store.decode_catalog(incoming.read_bytes()) if incoming.exists() else store.catalog();source={p['id']:p for p in catalog['profiles']}
            for change in changes:
                tool=change.get('tool');desired=change.get('desired',{})
                if not isinstance(tool,int) or isinstance(tool,bool) or tool not in range(store.tool_count()) or tool in seen:raise ValueError('Tool duplicato o non disponibile')
                seen.add(tool)
                current=assignments.get(str(tool));previous=records.get((current or {}).get('library_id'))
                if current!=change.get('expected_assignment') or previous!=change.get('expected_record') or store.read_json('indx-tool-setup.json',{})!=change.get('expected_setup'):
                    ack=dict(request_id=ident,status='conflict',message='T%d modificato sul touch durante la sincronizzazione. Confronta i filamenti in Orca.'%tool)
                    store.write_json(ACK,ack);return ack
                color=desired.get('color','')
                if not isinstance(color,str) or not re.fullmatch(r'#[0-9A-Fa-f]{6}',color):raise ValueError('Colore non valido')
                key=desired.get('library_id')
                if key:
                    if key not in records:raise ValueError('Filamento personale non disponibile: sincronizza la libreria')
                    record=copy.deepcopy(records[key])
                    if record.get('color','').upper()!=color.upper() and any(t!=str(tool) and a.get('library_id')==key for t,a in assignments.items()):
                        # A tool color is independent even when the same calibrated
                        # library record was selected in several project slots.
                        record.pop('library_id',None);record['name']+=' - colore Orca'
                    record['color']=color.upper()
                    # A library record may already be loaded by another tool. The
                    # existing shared-identity semantics intentionally update its color.
                else:
                    profile=source.get(desired.get('profile_id'))
                    if not profile or not profile.get('compatible'):raise ValueError('Base Orca assente o incompatibile: sincronizza il catalogo')
                    record=store.stock_record(profile,tool,color.upper())
                record.setdefault('library_id',__import__('uuid').uuid4().hex);record['updated']=time.time()
                records[record['library_id']]=record;updates.append((tool,record))
            # Recompute shared assignments only after the full batch validated.
            for t,assignment in list(assignments.items()):
                key=assignment.get('library_id')
                if key in records and int(t)<store.tool_count():assignments[t]=store.for_tool(records[key],int(t))
            for tool,record in updates:assignments[str(tool)]=store.for_tool(records[record['library_id']],tool)
            ack=dict(request_id=ident,status='applied',message='Filamenti e colori aggiornati da Orca',tools=sorted(seen))
            # The write-ahead snapshot recovers an interrupted two-file commit.
            store.write_json('indx-orca-sync-journal.json',{'indx-filament-library.json':{'schema':3,'profiles':records},'indx-filament-assignments.json':assignments,ACK:ack})
            store.recover_sync();return ack
        except (ValueError,TypeError,KeyError) as error:
            ack=dict(request_id=ident,status='error',message=str(error));store.write_json(ACK,ack);return ack

def poll(busy=None):
    request=store.read_json(REQUEST,{})
    if not request:return
    old=store.read_json(ACK,{})
    if old.get('request_id')==request.get('request_id') and old.get('status') in ('applied','conflict','error'):return
    if busy and busy():return
    return apply_request(request)

def printer_busy():
    with urlopen('http://127.0.0.1:7125/printer/objects/query?print_stats',timeout=2) as response:
        state=json.load(response)['result']['status']['print_stats']['state']
    return state in ('printing','paused')

def main():
    logging.basicConfig(level=logging.INFO)
    while True:
        try:poll(printer_busy)
        except Exception:logging.exception('INDX filament sync deferred')
        time.sleep(1)
if __name__=='__main__':main()
